
package Formularios;

import Usuarios.admin.Login_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Incio_201708938 {

    JFrame Finicio = new JFrame();
    JPanel Pinicio = new JPanel();
    JLabel titulo = new JLabel();
    JTextArea mision = new JTextArea();
    JButton BAbout = new JButton();
    JButton BLogin = new JButton();
    //About
     JLabel img = new JLabel();      
     ImageIcon imgIcon = new ImageIcon(getClass().getResource("/imagenes/logoUsac_201708938.png"));
    Login_201708938 log = new Login_201708938();
    public Incio_201708938() {
        configuraInicio();
        Finicio.show(true);
        BAbout.addActionListener((new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                abrirAbout();
            }
        }));
        BLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                log.Login();
                Finicio.show(false);
            }
        });
         log.BCancelar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        log.Flogin.dispose();
                        Finicio.show(true);
                    }
                });
    }
    
    public void configuraInicio(){
         Finicio.setSize(750,450);
    Finicio.setLocationRelativeTo(null);
    Finicio.setTitle("Inicio");
    Finicio.setDefaultCloseOperation(Finicio.EXIT_ON_CLOSE);
    Finicio.add(Pinicio);
    Pinicio.setLayout(null);
    Pinicio.setBounds(0,0,Finicio.getWidth(),Finicio.getHeight());
    Pinicio.setBackground(Color.decode("#BCE081"));
    titulo.setText("BIBLIOTECA - USAC");
    titulo.setFont(new Font("Serif",Font.PLAIN,32));
    titulo.setForeground(Color.decode("#EDA921"));
    titulo.setBounds(210,15,450,50);
    Pinicio.add(titulo);
    mision.setText("΁ MISIÓN: Ser una institución que vela por la formación y especialización de profesionales, estudiantes y usuarios externos, mediante la prestacion de servicios de calidad y efience, brindando recursos y materiales impresos. \n ΁ VISIÓN: Convertirse en el centro sobresaliente de formación a nivel Nacional,que promueva vínculos de unidades de informacion a nivel nacional y mundial. ");
    mision.setFont(new Font("Serif",Font.BOLD,13));
    mision.setLineWrap(true);
    mision.setEditable(false);
    mision.setBackground(Color.decode("#BCE051"));
    mision.setForeground(Color.white);
    mision.setBounds(45,72,650,75);
    Pinicio.add(mision);
    BAbout.setText("ABOUT");
    BAbout.setBounds(50,180,120, 60);
    Pinicio.add(BAbout);
    BLogin.setText("LOGIN");
    BLogin.setBounds(50,280, 120, 60);
    Pinicio.add(BLogin);
    img.setIcon(imgIcon);
    img.setBounds(320,200,400,120);
    Pinicio.add(img);
    }
    public void abrirAbout(){
        JOptionPane.showMessageDialog(BAbout,"\t ABOUT:  \nCarlos Fernando León Martínez \n 201708938 \n IPC-1", "",JOptionPane.NO_OPTION);
    }
    
}