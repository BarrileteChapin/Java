
package Prestamo;

public class Prestamo_201708938 {

    public String usuario;
    public String tipoDeBibliografía;
    public String titulo;
    public String autor;
    public int copias;
    public String fechaPrestado;
    public String estado;

    public Prestamo_201708938(String usuario, String tipoDeBibliografía, String titulo, String autor, int copias, String fechaPrestado, String estado) {
        this.usuario = usuario;
        this.tipoDeBibliografía = tipoDeBibliografía;
        this.titulo = titulo;
        this.autor = autor;
        this.copias = copias;
        this.fechaPrestado = fechaPrestado;
        this.estado = estado;
    }

    

    
}
