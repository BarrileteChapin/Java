package Prestamo;

public class PrestamosSearch_201708938 {

int total_prestamos = 1000;
public Prestamo_201708938 prestamo[] = new Prestamo_201708938[total_prestamos];

public int posición_crearPrestamo;
int posición_ModificarPrestamo;

    public void setPosición_crearPrestamo(int posición_crearPrestamo) {
        this.posición_crearPrestamo = posición_crearPrestamo;
    }

    public void setPosición_ModificarPrestamo(int posición_ModificarPrestamo) {
        this.posición_ModificarPrestamo = posición_ModificarPrestamo;
    }
    

public void crearPrestamo(String usuario, String tipoDeBibliografía, String titulo, String autor, int copias, String fechaPrestado, String estado){
    prestamo[posición_crearPrestamo] = new Prestamo_201708938(usuario, tipoDeBibliografía, titulo, autor, copias, fechaPrestado, estado);
}

public void modificarPrestamo(String usuario, String tipoDeBibliografía, String titulo, String autor, int copias, String fechaPrestado, String estado){

    prestamo[posición_ModificarPrestamo] = new Prestamo_201708938(usuario, tipoDeBibliografía, titulo, autor, copias, fechaPrestado, estado);
}
}
