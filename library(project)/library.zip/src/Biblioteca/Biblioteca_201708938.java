
package Biblioteca;


public class Biblioteca_201708938 {

    public int limite_estantería = 120;
    public Revista_201708938 revista[] = new Revista_201708938[limite_estantería];
    public Libro_201708938 libro[] = new Libro_201708938[limite_estantería];
    public Tesis_201708938 tesis[] = new Tesis_201708938[limite_estantería];

    public int posición_Clibro;
    public int posición_Crevista;
    public int posición_Ctesis;
    
    public Biblioteca_201708938() {
    
    }

    public int getPosición_Clibro() {
        return posición_Clibro;
    }

    public int getPosición_Crevista() {
        return posición_Crevista;
    }

    public int getPosición_Ctesis() {
        return posición_Ctesis;
    }

    public void setPosición_Clibro(int posición_Clibro) {
        this.posición_Clibro = posición_Clibro;
    }

    public void setPosición_Crevista(int posición_Crevista) {
        this.posición_Crevista = posición_Crevista;
    }

    public void setPosición_Ctesis(int posición_Ctesis) {
        this.posición_Ctesis = posición_Ctesis;
    }
    
    public void crearRevista(String autor, String título, int edición, String descripción, String frecuencia_actual, int ejemplares, String[] temas, String[] palabrasClave, int copias, int displinibles){
        revista[posición_Crevista]= new Revista_201708938(autor,título,edición,descripción,frecuencia_actual,ejemplares,temas,palabrasClave,copias,displinibles);
    }
    public void crearLibro(String autor, String título, int edición,String[]palabrasClaves,String descripcion,String[] temas, int copias, int disponibles){
        libro[posición_Clibro]= new Libro_201708938(autor, título, edición, palabrasClaves, descripcion, temas, copias, disponibles);
    }
    public void crearTesis(String autor, String título, String[] palabrasClave, String area, String[] temas, String descripción, int edición, int copias, int disponibles){
        tesis[posición_Ctesis]= new Tesis_201708938(autor, título, palabrasClave, area, temas, descripción, edición, copias, disponibles);
    }
    
    
}
