
package Biblioteca;

public class Tesis_201708938 {
    public String autor;
    public String título;
    public String[] palabrasClave;
    public String area;
    public String[] temas;
    public String descripción;
    public int edición;
    public int copias;
    public int disponibles;
    
     public int numeroDeBusqueda=0;
     public int numeroDePrestado=0;

    public Tesis_201708938(String autor, String título, String[] palabrasClave, String area, String[] temas, String descripción, int edición, int copias, int disponibles) {
        this.autor = autor;
        this.título = título;
        this.palabrasClave = palabrasClave;
        this.area = area;
        this.temas = temas;
        this.descripción = descripción;
        this.edición = edición;
        this.copias = copias;
        this.disponibles = disponibles;
    }
    
    
}
