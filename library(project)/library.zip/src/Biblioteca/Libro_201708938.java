package Biblioteca;

public class Libro_201708938 {

    public String autor;
    public String título;
    public int edición;
    public String[] palabrasClaves;
    public String descripción;
    public String[] temas;
    public int copias;
    public int disponibles;
    
    public int numeroDeBusqueda =0;
    public int numeroDePrestado =0;

    public Libro_201708938(String autor, String título, int edición, String[] palabrasClaves, String descripción, String[] temas, int copias, int disponibles) {
        this.autor = autor;
        this.título = título;
        this.edición = edición;
        this.palabrasClaves = palabrasClaves;
        this.descripción = descripción;
        this.temas = temas;
        this.copias = copias;
        this.disponibles = disponibles;
    }

   
    

    
    
}
