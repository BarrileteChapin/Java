
package Biblioteca;


public class Revista_201708938 {
    
    public String autor;
    public String título;
    public int edición;
    public String descripción;
    public String frecuencia_actual;
    public int ejemplares;
    public String[] temas;
    public String[] palabrasClave;
    public int copias;
    public int displinibles;
    
     public int numeroDeBusqueda =0;
     public int numeroDePrestado=0;

    public Revista_201708938(String autor, String título, int edición, String descripción, String frecuencia_actual, int ejemplares, String[] temas, String[] palabrasClave, int copias, int displinibles) {
        this.autor = autor;
        this.título = título;
        this.edición = edición;
        this.descripción = descripción;
        this.frecuencia_actual = frecuencia_actual;
        this.ejemplares = ejemplares;
        this.temas = temas;
        this.palabrasClave = palabrasClave;
        this.copias = copias;
        this.displinibles = displinibles;
    }
    
    
}
