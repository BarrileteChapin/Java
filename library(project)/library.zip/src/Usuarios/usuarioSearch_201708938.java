package Usuarios;


public class usuarioSearch_201708938 {
    
    public int contador_usuario = 0;
    public int total_usuario = 20;
    public usuario_201708938 usuarioLista [] = new usuario_201708938[total_usuario];
    public int estadoEncontrado = 0;
   // usuarioLista[1] = new usuario(0,"admin","admin","administrador","admin");
    public int correlativo_modificar;
    
    public usuarioSearch_201708938() {
    usuarioLista[0] = new usuario_201708938("admin","Carlos","León","Administrador","admin");
    usuariosCreados();
    contador_usuario++;
    
    }
 
    public void searchAdmin(){
        
    }
    
    public void busqueda(String nombre_usuario,String contraseña_usuario){
        estadoEncontrado =0;
        for (int i = 0; i <= contador_usuario; i++) {
            //nombreU = cui 
            String nombreU = usuarioLista[i ].getCUI();
             String contraseñaU = usuarioLista[i].getPassword();
             try {
                  
           if((nombreU.equals(nombre_usuario) ) && ((contraseñaU).equals(contraseña_usuario)) ){
               System.out.println("usuario encontrado");
               estadoEncontrado = 1;
               if (nombreU.equals("admin")&&contraseñaU.equals("admin")) {
                   estadoEncontrado = 4;
                   break;
                }
               
             }else if( (nombreU.equals(nombre_usuario) ) && (!contraseñaU.equals(contraseña_usuario)) ){
               System.out.println("No coincide la contraseña");
               estadoEncontrado = 2;
            }
            } catch (Exception e) {
                    continue;
            }
        }
    }

    public int getContador_usuario() {
        return contador_usuario;
    }

    public void setContador_usuario(int contador_usuario) {
        this.contador_usuario = contador_usuario;
    }
    
    public void crearUsuario(String cui, String nombre, String apellido, String rol, String contraseña){ 
     usuarioLista[contador_usuario] = new usuario_201708938(cui, nombre, apellido, rol, contraseña);
        System.out.println(contador_usuario);
        
    }
    public void buscarEspacio(){
        try {
        for (int i = 0; i <= usuarioLista.length; i++) {
            contador_usuario = contador_usuario +1;
            if(usuarioLista[i].getCUI().length() ==0){
                setContador_usuario(contador_usuario);
                System.err.println("Espacio " +contador_usuario);
                break;
            }
            System.err.println("Espacio " +i);
        
        }} catch (Exception e) {
        }
    }
    
    public void usuariosCreados(){
        try {
        for (int i = 0; i <= contador_usuario; i++) {
            System.out.println(usuarioLista[i].getNombre());
        }
        } catch (Exception e) {
        }
    }

    public int getCorrelativo_modificar() {
        return correlativo_modificar;
    }

    public void setCorrelativo_modificar(int correlativo_modificar) {
        this.correlativo_modificar = correlativo_modificar;
    }
    
    
    public void modificarUsuario(String cui,String nombre,String apellido, String rol,String contraseña ){
        usuarioLista[correlativo_modificar] = new usuario_201708938(cui, nombre, apellido, rol, contraseña);
        System.out.println("Correlativo Search "+correlativo_modificar);
    }

}

