package Usuarios.normal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;

public class DevuelveBibliografia_201708938 {
    
JFrame FdevolverBibliografia = new JFrame();
JPanel PdevolverBibliografia = new JPanel();
JLabel nAutor = new JLabel();
JLabel nPalabrasClaves = new JLabel();
JLabel nTema = new JLabel();
JLabel nCopias = new JLabel();
JLabel nEdición = new JLabel();
JLabel nDescripción = new JLabel();
JLabel nTitulo = new JLabel();
JTextField Tautor = new JTextField();
JTextField TPalabrasClaves = new JTextField();
JTextField Ttemas = new JTextField();
JTextField Tcopias = new JTextField();
JTextField Tedición = new JTextField();
JButton BdevolverBibliografia = new JButton();
JButton Bcancelar = new JButton();
JTextArea Adescripción = new JTextArea();
JComboBox Ttitulo = new JComboBox();
JComboBox CopcionBibliografia = new JComboBox();
JLabel nOpcionBibliografía = new JLabel();
JTextField TareaAcademica = new JTextField();
JLabel nAreaAcademica = new JLabel();
JButton Bbuscar = new JButton();

JScrollPane Sdescripción = new JScrollPane(Adescripción);
JScrollPane SpalabrasClaves = new JScrollPane(TPalabrasClaves);
JScrollPane Stemas = new JScrollPane(Ttemas);

JTextField TfrecuenciaActual = new JTextField();
JLabel nFrecuenciaActual = new JLabel();

public int Posicion_devolver;
public int Posición_modificando = -1;


    public DevuelveBibliografia_201708938(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId) {
    configurarUsuario();
    FdevolverBibliografia.show(true);
    llenarCopcion();
    cambiandoForm();
    obtenerTituloCombo(libreria, prestamito, usuarioId);
    setEditable();
    
    }
    
public void configurarUsuario(){
    FdevolverBibliografia.setSize(750,900);
    FdevolverBibliografia.setLocationRelativeTo(null);
    FdevolverBibliografia.setTitle("Devolviendo Bibliografía ");
    FdevolverBibliografia.setDefaultCloseOperation(FdevolverBibliografia.EXIT_ON_CLOSE);
    FdevolverBibliografia.add(PdevolverBibliografia );
    PdevolverBibliografia.setLayout(null);
    PdevolverBibliografia.setBounds(0,0,FdevolverBibliografia.getWidth(),FdevolverBibliografia.getHeight());
    PdevolverBibliografia.setBackground(Color.decode("#BCE081"));
    
    nTitulo.setText("Titulo: ");
    nTitulo.setFont(new Font("Arial",Font.BOLD,25));
    nTitulo.setForeground(Color.orange);
    nTitulo.setBounds(10,30,150,20);
    PdevolverBibliografia.add(nTitulo);
    Ttitulo.setBounds(110,30,280,30);
    PdevolverBibliografia.add(Ttitulo);
    nOpcionBibliografía.setText("Tipo: ");
    nOpcionBibliografía.setFont(new Font("Serif",Font.BOLD,25));
    nOpcionBibliografía.setForeground(Color.LIGHT_GRAY);
    nOpcionBibliografía.setBounds(480,30,100,30);
    PdevolverBibliografia.add(nOpcionBibliografía);
    CopcionBibliografia.setBounds(580,30,80,50);
    PdevolverBibliografia.add(CopcionBibliografia);
    Bbuscar.setText("Buscar");
    Bbuscar.setBounds(180,65,120,30);
    PdevolverBibliografia.add(Bbuscar);
    nAutor.setText("Autor: ");
    nAutor.setBounds(10,125,90,30);
    nAutor.setFont(new Font("Serif",Font.BOLD,20));
    nAutor.setForeground(Color.orange);
    PdevolverBibliografia.add(nAutor);
    Tautor.setBounds(110,125,300,40);
    Tautor.setFont(new Font("Serif",Font.BOLD,15));
    PdevolverBibliografia.add(Tautor);
    nEdición.setText("Edición ");
    nEdición.setBounds(480,115,90,30);
    nEdición.setFont(new Font("Serif",Font.BOLD,20));
    nEdición.setForeground(Color.orange);
    PdevolverBibliografia.add(nEdición);
    Tedición.setBounds(580,115,80,40);
    Tedición.setFont(new Font("Serif",Font.BOLD,15));
    PdevolverBibliografia.add(Tedición);
    nTema.setText("Temas: ");
    nTema.setBounds(10,225,90,30);
    nTema.setFont(new Font("Serif",Font.BOLD,20));
    nTema.setForeground(Color.orange);
    PdevolverBibliografia.add(nTema);
    Stemas.setBounds(110,225,300,40);
    Stemas.setFont(new Font("Serif",Font.BOLD,15));
    PdevolverBibliografia.add(Stemas);
    nCopias.setText("Copias: ");
    nCopias.setBounds(480,225,90,30);
    nCopias.setFont(new Font("Serif",Font.BOLD,20));
    nCopias.setForeground(Color.orange);
    PdevolverBibliografia.add(nCopias);
    Tcopias.setBounds(580,225,80,40);
    Tcopias.setFont(new Font("Serif",Font.BOLD,15));
    PdevolverBibliografia.add(Tcopias);
    nPalabrasClaves.setText("Palabras claves: ");
    nPalabrasClaves.setBounds(10,320,160,30);
    nPalabrasClaves.setFont(new Font("Serif",Font.BOLD,20));
    nPalabrasClaves.setForeground(Color.orange);
    PdevolverBibliografia.add(nPalabrasClaves);
    SpalabrasClaves.setBounds(180,320,450,40);
    SpalabrasClaves.setFont(new Font("Serif",Font.BOLD,15));
    PdevolverBibliografia.add(SpalabrasClaves);
    BdevolverBibliografia.setBounds(190,750,100,40);
    BdevolverBibliografia.setText("Prestar ");
    PdevolverBibliografia.add(BdevolverBibliografia);
    Bcancelar.setBounds(375,750,100,40);
    Bcancelar.setText("Cancelar");
    PdevolverBibliografia.add(Bcancelar);
    
    nDescripción.setText("Descripción: ");
    nDescripción.setBounds(30,385,200,200);
    nDescripción.setFont(new Font("Serif",Font.BOLD,28));
    nDescripción.setForeground(Color.orange);
    PdevolverBibliografia.add(nDescripción);
    Sdescripción.setBounds(250,380,380,200);
    PdevolverBibliografia.add(Sdescripción);
}

public void configurarParaTesis(){
    nAreaAcademica.setText("Area academica");
    nAreaAcademica.setBounds(30,600,180,50);
    nAreaAcademica.setFont(new Font("Serif",Font.BOLD,20));
    nAreaAcademica.setForeground(Color.orange);
    PdevolverBibliografia.add(nAreaAcademica);
    TareaAcademica.setBounds(250,600,390,50);
    TareaAcademica.setFont(new Font("Serif",Font.BOLD,18));
    PdevolverBibliografia.add(TareaAcademica);
   
}
public void configurarParaRevista(){
    nFrecuenciaActual.setText("Frecuencia Actual: ");
    nFrecuenciaActual.setBounds(30,600,180,50);
    nFrecuenciaActual.setFont(new Font("Serif",Font.BOLD,20));
    nFrecuenciaActual.setForeground(Color.orange);
    PdevolverBibliografia.add(nFrecuenciaActual);
    TfrecuenciaActual.setBounds(250,600,390,50);
    TfrecuenciaActual.setFont(new Font("Serif",Font.BOLD,18));
    PdevolverBibliografia.add(TfrecuenciaActual);
    
}
 public void setEditable(){
        Ttemas.setEditable(false);
        TPalabrasClaves.setEditable(false);
        TareaAcademica.setEditable(false);
        Tcopias.setEditable(false);
        TfrecuenciaActual.setEditable(false);
        Tedición.setEnabled(false);
        Adescripción.setEnabled(false);
        Tautor.setEditable(false);
        CopcionBibliografia.setEditable(false);
    }

    public void limitarField(){
     Tautor.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tautor.getText().length()>13){
                e.consume();
                JOptionPane.showMessageDialog(PdevolverBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
     Ttemas.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Ttemas.getText().length()>60){
                e.consume();
                JOptionPane.showMessageDialog(PdevolverBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    TPalabrasClaves.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(TPalabrasClaves.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PdevolverBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    Tcopias.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tcopias.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PdevolverBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    }
    
    public void buscando(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId){
        Posición_modificando =-1;
        Posicion_devolver = -1;
        String titulo = Ttitulo.getSelectedItem().toString();
        for (int i = 0; i < libreria.libro.length; i++) {
            try {
                if (titulo.equals(libreria.libro[i].título)) {
                    for (int j = 0; j < prestamito.prestamo.length; j++) {
                        try {
                            if (prestamito.prestamo[j].usuario.equals(usuarioId)&& prestamito.prestamo[j].titulo.equals(titulo)&&prestamito.prestamo[j].estado.equals("prestado")) {
                                Posicion_devolver = j;
                                Posición_modificando = i;
                                CopcionBibliografia.setSelectedItem("(0) Libro");
                                CopcionBibliografia.setEnabled(false);
                                obtenerDatosLibro(libreria);
                            
                            }
                        } catch (Exception e) {
                        continue;
                        }
                    }
            }
            } catch (Exception e) {
                continue;
            }
            
        }
        for (int i = 0; i < libreria.revista.length; i++) {
            try {
             if (titulo.equals(libreria.revista[i].título)) {
                 for (int j = 0; j < prestamito.prestamo.length; j++) {
                     try {
                         if (prestamito.prestamo[j].usuario.equals(usuarioId)&& prestamito.prestamo[j].titulo.equals(titulo) && prestamito.prestamo[j].estado.equals("prestado")) {
                             Posicion_devolver = j;
                             Posición_modificando = i;
                             CopcionBibliografia.setSelectedItem("(1) Revista");
                             CopcionBibliografia.setEnabled(false);
                             obtenerDatosRevista(libreria);  
                         } 
                     } catch (Exception e) {
                         continue;
                     }
                 }
            }
            } catch (Exception e) {
                continue;
            }
           
        }    
        for (int i = 0; i < libreria.tesis.length; i++) {
            try {
                if (titulo.equals(libreria.tesis[i].título)) {
                 for (int j = 0; j < prestamito.prestamo.length; j++) {
                     try {
                         if (prestamito.prestamo[j].usuario.equals(usuarioId)&& prestamito.prestamo[j].titulo.equals(titulo) && prestamito.prestamo[j].estado.equals("prestado")) {
                             Posicion_devolver=j;
                             Posición_modificando = i;
                             CopcionBibliografia.setSelectedItem("(2) Tesis");
                             CopcionBibliografia.setEnabled(false);
                             obtenerDatosTesis(libreria);
                         } 
                     } catch (Exception e) {
                         continue;
                     }
                 }
            }
            } catch (Exception e) {
                continue;
            }
        }
        if (Posición_modificando==-1||Posicion_devolver==-1) {
            JOptionPane.showMessageDialog(PdevolverBibliografia,"No se encuentra una biliografia de "+titulo+"");
        }
        
    }
    public void modificarSegúnOpcion(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId){
        if (CopcionBibliografia.getSelectedItem().equals("(0) Libro")) {
            modificandoLibro(libreria,prestamito,usuarioId);
        }else if (CopcionBibliografia.getSelectedItem().equals("(1) Revista")) {
            modificandoRevista(libreria,prestamito,usuarioId);
        }else{
            modificandoTesis(libreria,prestamito,usuarioId);
        }
    }
    
    public void modificandoLibro(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId){
        String título = Ttitulo.getSelectedItem().toString();       
        String estado="Devuelto";
        int option = JOptionPane.showConfirmDialog(PdevolverBibliografia,"¿Deseas devolver el Libro: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        
        switch(option){
           
            case 1:
                libreria.setPosición_Clibro(Posición_modificando);
                libreria.libro[Posición_modificando].disponibles = libreria.libro[Posición_modificando].disponibles +1;
                prestamito.prestamo[Posicion_devolver].estado = estado;
                Ttitulo.removeAllItems();
                obtenerTituloCombo(libreria, prestamito, usuarioId);
                PdevolverBibliografia.repaint();    
                limpiar();
                break;
            case 2: 
                limpiar();
                break;
            default:
                break;
        }
    }
    
    public void modificandoRevista(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito, String usuarioId){
        String título = Ttitulo.getSelectedItem().toString();
        String estado="Devuelto";
        int option = JOptionPane.showConfirmDialog(PdevolverBibliografia,"¿Deseas devolver la Revista: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        try {
        switch(option){
           
            case 1:
                libreria.setPosición_Crevista(Posición_modificando);
                libreria.revista[Posición_modificando].displinibles = libreria.revista[Posición_modificando].displinibles +1;
                prestamito.setPosición_ModificarPrestamo(Posicion_devolver);
                prestamito.prestamo[Posicion_devolver].estado = estado;
                Ttitulo.removeAllItems();
                obtenerTituloCombo(libreria, prestamito, usuarioId);
                limpiar();
                TfrecuenciaActual.setText(null);
                break;
            case 2: 
                limpiar();
                TfrecuenciaActual.setText(null);
                break;
            default:
                break;
        }
        } catch (Exception e) {
        }        
        
    }
    
    
    public void modificandoTesis(Biblioteca.Biblioteca_201708938 libreria,Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId){
        String título = Ttitulo.getSelectedItem().toString();
        String estado="Devuelto";
        
        int option = JOptionPane.showConfirmDialog(PdevolverBibliografia,"¿Deseas devolver la Tesis: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        try {
        switch(option){
           
            case 1:
                libreria.setPosición_Ctesis(Posición_modificando);
                libreria.tesis[Posición_modificando].disponibles = libreria.tesis[Posición_modificando].disponibles +1;
                prestamito.setPosición_ModificarPrestamo(Posicion_devolver);
                prestamito.prestamo[Posicion_devolver].estado = estado;
                Ttitulo.removeAllItems();
                obtenerTituloCombo(libreria, prestamito, usuarioId);
                limpiar();
                TareaAcademica.setText(null);
                break;
            case 2: 
                limpiar();
                TareaAcademica.setText(null);
                break;
            default:
                break;
        }
        } catch (Exception e) {
        }     
        
    }
    
    
    public void limpiar(){
        Tautor.setText(null);
        Ttemas.setText(null);
        Tcopias.setText(null);
        Tedición.setText(null);
        TPalabrasClaves.setText(null);
        Adescripción.setText(null);
    }
    
    public void llenarCopcion(){
        CopcionBibliografia.addItem("(0) Libro");
        CopcionBibliografia.addItem("(1) Revista");
        CopcionBibliografia.addItem("(2) Tesis");
    }
    
    public void cambiandoForm(){
        CopcionBibliografia.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
           
                if(CopcionBibliografia.getSelectedItem().equals("(0) Libro")){
                    PdevolverBibliografia.removeAll();
                    PdevolverBibliografia.repaint();
                    configurarUsuario();
            }else if (CopcionBibliografia.getSelectedItem().equals("(1) Revista")) {
                    PdevolverBibliografia.removeAll();
                    PdevolverBibliografia.repaint();
                    configurarUsuario();
                    configurarParaRevista();
                }else if (CopcionBibliografia.getSelectedItem().equals("(2) Tesis")) {
                    PdevolverBibliografia.removeAll();
                    PdevolverBibliografia.repaint();
                    configurarUsuario();
                    configurarParaTesis();
                }
                
            }
        });
        
    }
    
    public void obtenerDatosLibro(Biblioteca.Biblioteca_201708938 libreria){
         String buscaTemas="";
         String buscaPalabras="";
         Tautor.setText(libreria.libro[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.libro[Posición_modificando].edición));
         for (int i = 0; i < libreria.libro[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.libro[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.libro[Posición_modificando].copias));
         for (int i = 0; i < libreria.libro[Posición_modificando].palabrasClaves.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.libro[Posición_modificando].palabrasClaves[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.libro[Posición_modificando].descripción);
    }
    
    public void obtenerDatosRevista(Biblioteca.Biblioteca_201708938 libreria){
         String buscaTemas="";
         String buscaPalabras="";
         Tautor.setText(libreria.revista[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.revista[Posición_modificando].edición));
         for (int i = 0; i < libreria.revista[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.revista[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.revista[Posición_modificando].copias));
         for (int i = 0; i < libreria.revista[Posición_modificando].palabrasClave.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.revista[Posición_modificando].palabrasClave[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.revista[Posición_modificando].descripción);
        TfrecuenciaActual.setText(libreria.revista[Posición_modificando].frecuencia_actual);
    }
    
    public void obtenerDatosTesis(Biblioteca.Biblioteca_201708938 libreria){
        String buscaTemas="";
         String buscaPalabras="";
         Tautor.setText(libreria.tesis[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.tesis[Posición_modificando].edición));
         for (int i = 0; i < libreria.tesis[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.tesis[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.tesis[Posición_modificando].copias));
         for (int i = 0; i < libreria.tesis[Posición_modificando].palabrasClave.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.tesis[Posición_modificando].palabrasClave[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.tesis[Posición_modificando].descripción);
         TareaAcademica.setText(libreria.tesis[Posición_modificando].area);
    }
    
    public void obtenerTituloCombo(Biblioteca.Biblioteca_201708938 libreria, Prestamo.PrestamosSearch_201708938 prestamito,String usuarioId){
        for (int i = 0; i < prestamito.prestamo.length; i++) {
            try {
                if (prestamito.prestamo[i].usuario.equals(usuarioId)&& !prestamito.prestamo[i].estado.equals("Devuelto")) {
                    Ttitulo.addItem(prestamito.prestamo[i].titulo);
                }
            } catch (Exception e) {
                continue;
            }
        }
    }

}
