package Usuarios.normal;

import Prestamo.PrestamosSearch_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class InicioUsuario_201708938 {
    
    public JFrame FinicioUsuario = new JFrame();
    JPanel PinicioUsuario = new JPanel();
    JLabel nUsuario = new JLabel();
   public JButton Bsalir = new JButton();
    JButton Bprestamo = new JButton();
    JButton Bdevolver = new JButton();
    JButton Bhistorial = new JButton();
    JButton Bbuscar = new JButton();
    
    JLabel imgFiusac = new JLabel();
    JLabel imgEcys = new JLabel();
    JLabel imgUser = new JLabel();
    ImageIcon IconFiusac = new ImageIcon(getClass().getResource("/imagenes/fiusac_201708938.png"));
    ImageIcon IconEcys = new ImageIcon(getClass().getResource("/imagenes/ecys_201708938.jpeg  "));
    ImageIcon IconUser = new  ImageIcon(getClass().getResource("/imagenes/admi_201708938.png"));
    
    public Biblioteca.Biblioteca_201708938 libreria;
    public Usuarios.usuarioSearch_201708938 busqueda;
    public String usuarioId;
    public int correlativo_prestamo;
    public Prestamo.PrestamosSearch_201708938 prestamito = new PrestamosSearch_201708938();
    
            
    public InicioUsuario_201708938() {
        configurarInicioUsuario();
        pulsarBprestamo();
        pulsarBdevolver();
        pulsarBhistorial();
        pulsarBbuscarBibliografia();
    }
   
    
    public void configurarInicioUsuario(){
        FinicioUsuario.setSize(850,650);
        FinicioUsuario.setLocationRelativeTo(null);
        FinicioUsuario.setTitle("Inicio");
        FinicioUsuario.setDefaultCloseOperation(FinicioUsuario.EXIT_ON_CLOSE);
        FinicioUsuario.add(PinicioUsuario);
        PinicioUsuario.setLayout(null);
        PinicioUsuario.setBackground(Color.decode("#BCE081"));
        nUsuario.setText("Bienvenido ");
        nUsuario.setFont(new Font("Arial",Font.BOLD,28));
        nUsuario.setForeground(Color.WHITE);
        nUsuario.setBounds(200,20,200,100);
        PinicioUsuario.add(nUsuario);
        
        imgUser.setIcon(IconUser);
        imgUser.setBounds(80,15,100,140);
        PinicioUsuario.add(imgUser);
        
        Bsalir.setText("Salir");
        Bsalir.setBounds(630,30,150,50);
        Bsalir.setFont(new Font("Arial",Font.BOLD,22));
        PinicioUsuario.add(Bsalir);
        Bprestamo.setText("Prestamo de Bibliografía");
        Bprestamo.setForeground(Color.ORANGE);
        Bprestamo.setFont(new Font("Arial",Font.BOLD,16));
        Bprestamo.setBounds(80,180,270,50);
        PinicioUsuario.add(Bprestamo);
        Bdevolver.setText("Devolver Bibliografía");
        Bdevolver.setForeground(Color.ORANGE);
        Bdevolver.setFont(new Font("Arial",Font.BOLD,16));
        Bdevolver.setBounds(500,180,250,50);
        PinicioUsuario.add(Bdevolver);
        Bhistorial.setText("Historial");
        Bhistorial.setFont(new Font("Arial",Font.BOLD,16));
        Bhistorial.setBounds(80,280,270,50);
        Bhistorial.setForeground(Color.ORANGE);
        PinicioUsuario.add(Bhistorial);
        Bbuscar.setText("Busqueda de Bibliografía");
        Bbuscar.setForeground(Color.ORANGE);
        Bbuscar.setFont(new Font("Arial",Font.BOLD,14));
        Bbuscar.setBounds(500,280,250,50);
        PinicioUsuario.add(Bbuscar);
        
        imgFiusac.setIcon(IconFiusac);
        imgFiusac.setBounds(100,380,270,210);
        PinicioUsuario.add(imgFiusac);
        imgEcys.setIcon(IconEcys);
        imgEcys.setBounds(510,380,250,200);
        PinicioUsuario.add(imgEcys);
        
    }
 
    public void pulsarBprestamo(){
        Bprestamo.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                PrestaBibliografia_201708938 Presta_bibliografia = new PrestaBibliografia_201708938();
                FinicioUsuario.show(false);
                Presta_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        Presta_bibliografia.buscando(libreria);
                    }
                });
                Presta_bibliografia.BprestarBibliografia.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        if (Presta_bibliografia.Posición_modificando !=-1) {
                            correlativo_prestamo++;
                            Presta_bibliografia.correlativo = correlativo_prestamo;
                            try {
                            Presta_bibliografia.modificarSegúnOpcion(libreria,prestamito,usuarioId,busqueda);
                            } catch (Exception e) {
                            correlativo_prestamo--;
                                JOptionPane.showMessageDialog(Presta_bibliografia.PprestarBibliografia,"Busca una bibliografia "+e);
                            }
                            
                        }
                    }
                });
                
                
                Presta_bibliografia.Bcancelar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        Presta_bibliografia.FprestarBibliografia.show(false);
                        FinicioUsuario.show(true);
                        System.out.println("imprime lo guardado");
                            for (int i = 0; i <=correlativo_prestamo; i++) {
                                try {
                                    System.out.println(i);
                                    System.out.println("A "+prestamito.prestamo[i].autor);
                                    System.out.println("C "+prestamito.prestamo[i].copias);
                                    System.out.println("T "+prestamito.prestamo[i].titulo);
                                    System.out.println("t "+prestamito.prestamo[i].tipoDeBibliografía);
                                    System.out.println("F "+prestamito.prestamo[i].fechaPrestado);
                                } catch (Exception e) {
                                    continue;
                                }
                                
                            }        
                    }
                });
                
            }
        });
    }
    
    public void pulsarBdevolver(){
            Bdevolver.addActionListener(new ActionListener() {
                
                public void actionPerformed(ActionEvent ae) {
                    FinicioUsuario.show(false);
                    DevuelveBibliografia_201708938 devolver_bibliografia = new DevuelveBibliografia_201708938(libreria, prestamito, usuarioId);
                    devolver_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent ae) {
                            devolver_bibliografia.buscando(libreria, prestamito, usuarioId);
                        }
                    });
                    
                    devolver_bibliografia.BdevolverBibliografia.addActionListener(new ActionListener() {
                        
                        public void actionPerformed(ActionEvent ae) {
                            if (devolver_bibliografia.Posicion_devolver!=-1&&devolver_bibliografia.Posicion_devolver!=-1) {
                                 devolver_bibliografia.modificarSegúnOpcion(libreria, prestamito, usuarioId);
                            }else{
                                JOptionPane.showMessageDialog(devolver_bibliografia.PdevolverBibliografia,"No se puede devolver");
                            }
                        }
                    });
                    
                    devolver_bibliografia.Bcancelar.addActionListener(new ActionListener() {
                        
                        public void actionPerformed(ActionEvent ae) {
                            devolver_bibliografia.FdevolverBibliografia.show(false);
                            FinicioUsuario.show(true);
                        }
                    });
                }
            });
    }
    
    public void pulsarBhistorial(){
       Bhistorial.addActionListener(new ActionListener() {
          
           public void actionPerformed(ActionEvent ae) {
               HistorialBibliografía_201708938 historial_bibliografia = new HistorialBibliografía_201708938(prestamito);
               FinicioUsuario.show(false);
               historial_bibliografia.usuarioId = usuarioId;
               //historial_bibliografia.buscarInformación(prestamito);
               historial_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                    historial_bibliografia.buscarPrestado(prestamito);
                    historial_bibliografia.extraerFilas();
                   }
               });
              historial_bibliografia.CordenarPor.addActionListener(new ActionListener() {
                   @Override
                   public void actionPerformed(ActionEvent ae) {
                    historial_bibliografia.limpiarTabla();
                     historial_bibliografia.ordenarSegunCombo(prestamito);
                   }
               });
               
               historial_bibliografia.Bregresar.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                       historial_bibliografia.FhistorialBibliografía.dispose();
                       FinicioUsuario.show(true);
                   }
               });
           }
       });
        
    }
    
    
    public void pulsarBbuscarBibliografia(){
        Bbuscar.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                FinicioUsuario.show(true);
                MostrarBibliografia_201708938 mostrar_bibliografia = new MostrarBibliografia_201708938();
               mostrar_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                   
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.configurarMostrarBibliografia();
                        //mostrar_bibliografia.seleccionOpcion();
                        mostrar_bibliografia.buscarSegúnOpcion(libreria);
                        mostrar_bibliografia.extraerFilas();
                    }
                });
                mostrar_bibliografia.Ctipo.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.limpiarTabla();
                        mostrar_bibliografia.ordenarPorOpcionCorden();
                        System.out.println("Largo Modelo "+mostrar_bibliografia.modeloTabla.getRowCount());
                        System.out.println("Copias Lenght" + mostrar_bibliografia.copias.length);
                    }
                });
            
                mostrar_bibliografia.Bregresar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.FmodificarBibliografia.show(false);
                        FinicioUsuario.show(true);
                    }
                });
            }
        });
    }
    
    
    
}
