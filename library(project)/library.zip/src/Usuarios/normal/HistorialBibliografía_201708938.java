
package Usuarios.normal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class HistorialBibliografía_201708938 {
    
JFrame FhistorialBibliografía = new JFrame();
JPanel PhistorialBibliografía = new JPanel();
JLabel nUsuario = new JLabel();
JButton Bbuscar = new JButton();
JButton Bregresar = new JButton();
DefaultTableModel modeloTablaHistorial;
JTable TablaHistorial;
JScrollPane STablaHistorial = new JScrollPane();
public String usuarioId;
String [] columnas = {"Titulo","Autor","Tipo","Estado","Fecha de Prestado"};
JComboBox CordenarPor = new JComboBox();

String [][]recolectaDatos;
String [] estado,tipo,fecha;

    public HistorialBibliografía_201708938(Prestamo.PrestamosSearch_201708938 prestamito) {
        configurarHistorialBibliografia();
        llenarCombo();
        //accionCombo(prestamito);
        FhistorialBibliografía.show(true);
    }



public void configurarHistorialBibliografia(){
FhistorialBibliografía.setTitle("Historial de Usuario");
FhistorialBibliografía.setSize(950,750);
FhistorialBibliografía.setDefaultCloseOperation(FhistorialBibliografía.EXIT_ON_CLOSE);
FhistorialBibliografía.setLocationRelativeTo(null);
FhistorialBibliografía.add(PhistorialBibliografía);
PhistorialBibliografía.setBounds(0,0,FhistorialBibliografía.getWidth(),FhistorialBibliografía.getHeight());
PhistorialBibliografía.setLayout(null);
PhistorialBibliografía.setBackground(Color.decode("#BCE081"));
nUsuario.setText("Usuario: ");
nUsuario.setFont(new Font("Arial",Font.BOLD,35));
nUsuario.setForeground(Color.orange);
nUsuario.setBounds(30,30,400,90);
PhistorialBibliografía.add(nUsuario);
CordenarPor.setBounds(80,140,100,50);
PhistorialBibliografía.add(CordenarPor);
Bbuscar.setText("Buscar: ");
Bbuscar.setBounds(530,50,150,50);
PhistorialBibliografía.add(Bbuscar);
Bregresar.setText("Regresar");
Bregresar.setBounds(720, 50, 150,50);
PhistorialBibliografía.add(Bregresar);
modeloTablaHistorial = new DefaultTableModel(null,columnas);
TablaHistorial = new JTable(modeloTablaHistorial);
STablaHistorial.setViewportView(TablaHistorial);
STablaHistorial.setBounds(30,200,860,500);
PhistorialBibliografía.add(STablaHistorial);
}

public void llenarCombo(){
    CordenarPor.addItem("Estado");
    CordenarPor.addItem("Tipo");
    CordenarPor.addItem("Fecha");
}
public void buscarPrestado(Prestamo.PrestamosSearch_201708938 prestamito){
 /*  recolectaDatos = new String[prestamito.posición_crearPrestamo][5];
   estado = new String[prestamito.posición_crearPrestamo];
   tipo = new String[prestamito.posición_crearPrestamo];
   fecha = new String[prestamito.posición_crearPrestamo];
    int j =0;*/
    for (int i = 0; i <=prestamito.prestamo.length; i++) {
        try {
            if(prestamito.prestamo[i].usuario.equals(usuarioId)){
                String titulo = prestamito.prestamo[i].titulo;
                String autor = prestamito.prestamo[i].autor;
                String tipo = prestamito.prestamo[i].tipoDeBibliografía;
                String estado = prestamito.prestamo[i].estado;
                String fecha = prestamito.prestamo[i].fechaPrestado;
                String [] datos = {titulo,autor,tipo,estado,fecha};
                
             /*   recolectaDatos[i][0]=titulo;
                recolectaDatos[i][1]= autor;
                recolectaDatos[i][2] =tipo;
                recolectaDatos[i][3] = estado;
                recolectaDatos[i][4] = fecha;
              /*  
                this.estado[j] = estado;
                this.tipo[j] = tipo;
                this.fecha[j] = fecha;
                j++;
                */
                modeloTablaHistorial.addRow(datos);
            }
        } catch (Exception e) {
            continue;
        }
    }
    nUsuario.setText("Usuario: " +usuarioId);
}

public void accionCombo(Prestamo.PrestamosSearch_201708938 prestamito){
    CordenarPor.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            //buscarInformación(prestamito);
            ordenarSegunCombo(prestamito);
        }
    });
}
public void ordenarSegunCombo(Prestamo.PrestamosSearch_201708938 prestamito){
    if (CordenarPor.getSelectedItem().equals("Estado")) {
            for (int i = 1; i < estado.length; i++) {
                for (int j = 0; j < estado.length-1; j++) {
                    try {
                    if (estado[j].toString().compareTo(estado[j+1].toString())<0) {
                        String temp = estado[j].toString();
                        estado[j] = estado[j+1];
                        estado[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
    llenarTablaPorEstado(prestamito);
     }
    
     if (CordenarPor.getSelectedItem().equals("Tipo")) {
            for (int i = 1; i < tipo.length; i++) {
                for (int j = 0; j < tipo.length-1; j++) {
                    try {
                    if (tipo[j].toString().compareTo(tipo[j+1].toString())<0) {
                        String temp = tipo[j].toString();
                        tipo[j] = tipo[j+1];
                        tipo[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
         llenarTablaPorTipo(prestamito);
        }
     
      if (CordenarPor.getSelectedItem().equals("Fecha")) {
            for (int i = 1; i < fecha.length; i++) {
                for (int j = 0; j < fecha.length-1; j++) {
                    try {
                    if (fecha[j].toString().compareTo(fecha[j+1].toString())<0) {
                        String temp = fecha[j].toString();
                        fecha[j] = fecha[j+1];
                        fecha[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
          llenarTablaPorFecha(prestamito);
        }
      //nUsuario.setText("Usuario: " +usuarioId);
}

public void llenarTablaPorEstado(Prestamo.PrestamosSearch_201708938 prestamito){
    for (int i = 0; i <=estado.length; i++) {
        
        try {
         for (int j = 0; j <= estado.length; j++) {
            
            if(recolectaDatos[j][3].equals(estado[i])){
               try {
                String titulo = recolectaDatos[j][0];
                String autor = recolectaDatos[j][1];
                String tipos = recolectaDatos[j][2];
                String estados = recolectaDatos[j][3];
                String fechaa = recolectaDatos[j][4];
                String [] datos = {titulo,autor,tipos,estados,fechaa};
                modeloTablaHistorial.addRow(datos);
                } catch (Exception e) {
                System.out.println("estado " +e);
                System.out.println("estado" +i);
                continue;
                }
               }
           
        }
        }catch (Exception e) {
            System.out.println("Estado L "+estado.length);
        }
        }
    verificarDato();
    }


public void llenarTablaPorTipo(Prestamo.PrestamosSearch_201708938 prestamito){
    for (int i = 0; i <=tipo.length; i++) {
        try {
        for (int j = 0; j <=tipo.length; j++) {
             if(recolectaDatos[j][2].equals(tipo[i])){
               try {
                String titulo = recolectaDatos[j][0];
                String autor = recolectaDatos[j][1];
                String tipos = recolectaDatos[j][2];
                String estados = recolectaDatos[j][3];
                String fechaa = recolectaDatos[j][4];
                String [] datos = {titulo,autor,tipos,estados,fechaa};
                modeloTablaHistorial.addRow(datos);
                } catch (Exception e) {
                System.out.println("estado " +e);
                System.out.println("estado" +i);
                continue;
                }
               }
        }    
        } catch (Exception e) {
        
        } 
    }    
    verificarDato();
}

public void llenarTablaPorFecha(Prestamo.PrestamosSearch_201708938 prestamito){
    for (int i = 0; i <= fecha.length; i++) {
        try {
         for (int j = 0; j <= fecha.length; j++) {
            
             if(recolectaDatos[j][4].equals(fecha[i])){
               try {
                String titulo = recolectaDatos[j][0];
                String autor = recolectaDatos[j][1];
                String tipos = recolectaDatos[j][2];
                String estados = recolectaDatos[j][3];
                String fechaa = recolectaDatos[j][4];
                String [] datos = {titulo,autor,tipos,estados,fechaa};
                modeloTablaHistorial.addRow(datos);
                } catch (Exception e) {
                System.out.println("estado " +e);
                System.out.println("estado" +i);
                continue;
                }
               }
        }   
        } catch (Exception e) {
        }
    }
    verificarDato();
}
public void extraerFilas(){
        recolectaDatos = new String[modeloTablaHistorial.getRowCount()][5];
        estado = new String[modeloTablaHistorial.getRowCount()];
        fecha = new String[modeloTablaHistorial.getRowCount()];
        tipo = new String[modeloTablaHistorial.getRowCount()];
        
        for (int i = 0; i < modeloTablaHistorial.getRowCount(); i++) {
            String titulo = TablaHistorial.getValueAt(i,0).toString();
            String autor = TablaHistorial.getValueAt(i,1).toString();
            String tipo = TablaHistorial.getValueAt(i, 2).toString();
            String estado = TablaHistorial.getValueAt(i,3).toString();
            String fecha = TablaHistorial.getValueAt(i,4).toString();
            recolectaDatos[i][0]=titulo;
            recolectaDatos[i][1]= autor;
            recolectaDatos[i][2] =tipo;
            recolectaDatos[i][3] = estado;
            recolectaDatos[i][4] = fecha;
                
                this.estado[i] = estado;
                this.tipo[i] = tipo;
                this.fecha[i] = fecha;
            System.out.println("RowCount> " +modeloTablaHistorial.getRowCount());
            System.out.println("TItulo Obtain "+ titulo);
        }
    }
public void limpiarTabla(){
        for (int i = 0; i < modeloTablaHistorial.getRowCount(); i++) {
            modeloTablaHistorial.removeRow(i);
            i=-1;
        }
       // modeloTabla.setRowCount(0);
        TablaHistorial.repaint();
    }
public void verificarDato(){
        for (int i = 0; i < modeloTablaHistorial.getRowCount(); i++) {
            String a =modeloTablaHistorial.getValueAt(i,1).toString().trim();
            for (int j = i+1; j < modeloTablaHistorial.getRowCount(); j++) {
                if (a.equals(modeloTablaHistorial.getValueAt(j, 1).toString().trim())) {
                
                    try {
                     modeloTablaHistorial.removeRow(j); 
                        System.out.println("Se elimino "+j);
                    } catch (Exception e) {
                    
                    }
            }
            }
            
        }
        
    }

}
