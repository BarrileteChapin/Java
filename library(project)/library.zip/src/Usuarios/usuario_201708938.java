package Usuarios;


public class usuario_201708938 {


    private String CUI ;
    private String nombre;
    private String apellido;
    private String rol;
    private String password;
    public int numeroPrestamo=0;
    
    public usuario_201708938(String CUI, String nombre, String apellido, String rol, String password) {
        this.CUI = CUI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.rol = rol;
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getPassword() {
        return password;
    }

    public String getRol() {
        return rol;
    }

    public String getCUI() {
        return CUI;
    }
    
    
    public void setCUI(String CUI) {
        this.CUI = CUI;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  
    
}
