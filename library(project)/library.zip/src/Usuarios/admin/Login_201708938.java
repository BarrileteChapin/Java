
package Usuarios.admin;

import Biblioteca.Biblioteca_201708938;
import Formularios.Incio_201708938;
import Prestamo.PrestamosSearch_201708938;
import Usuarios.normal.InicioUsuario_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import Usuarios.usuarioSearch_201708938;

public class Login_201708938 {
    
    public JFrame Flogin = new JFrame();
    JPanel Plogin = new JPanel();
    JTextField user = new JTextField();
    JPasswordField password = new JPasswordField();
    JLabel usuario = new JLabel();
    JLabel contraseña = new JLabel();
    JButton BIngresar = new JButton();
    
    JLabel imgLogin = new JLabel();
    ImageIcon IconLogin = new ImageIcon(getClass().getResource("/imagenes/login_201708938.png"));

    public JButton BCancelar = new JButton();
    
    //Datos administrador
    int inicio_admi_correlativo;
    int inicio_admi_correlativo_creaBibliografiaL;
    int inicio_admin_correlativo_creaBibliografiaR;
    int inicio_admin_correlativo_creaBibliografiaT;
    InicioAdmin_201708938 inicio_admin;
    usuarioSearch_201708938 buscar = new usuarioSearch_201708938();
    Biblioteca_201708938 biblioteca = new Biblioteca_201708938();
    Prestamo.PrestamosSearch_201708938 prestamo = new PrestamosSearch_201708938();
    ///
    InicioUsuario_201708938 inicio_usuario;
    int correlativo_prestamo_usuario;
    
    public Login_201708938() {
  /*  configurarLogin();
    Flogin.show(true);
    /*BCancelar.addActionListener( new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            Incio inicio = new Incio();
            Flogin.show(false);
        }
    });
    BIngresar.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent ae) {
            logear(buscar);
        }
    });*/
    
    }
    
    public void Login(){
    configurarLogin();
    Flogin.show(true);
    /*BCancelar.addActionListener( new ActionListener() {
        public void actionPerformed(ActionEvent ae) {
            Incio inicio = new Incio();
            Flogin.show(false);
        }
    });*/
    BIngresar.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent ae) {
            logear(buscar);
        }
    });
    }


    
public void configurarLogin(){
    Flogin.setSize(750,525);
    Flogin.setTitle("Login");
    Plogin.setLayout(null);
    Flogin.setLocationRelativeTo(null);
    Flogin.setDefaultCloseOperation(Flogin.EXIT_ON_CLOSE);
    Flogin.add(Plogin);
    Plogin.setBounds(0, 0, Flogin.getWidth(), Flogin.getHeight());
    Plogin.setBackground(Color.decode("#AEFFF0"));
    
    imgLogin.setIcon(IconLogin);
    imgLogin.setBounds(250,15,180,160);
    Plogin.add(imgLogin);    
    
    usuario.setText("Nombre de usuario: ");
    usuario.setBounds(250,170,280,20);
    usuario.setForeground(Color.white);
    usuario.setFont(new Font("Serif",Font.BOLD,22));
    Plogin.add(usuario);
    user.setFont(new Font("Serif",Font.BOLD,22));
    user.setForeground(Color.decode("#BCE081"));
    user.setBounds(140,215,420,50);
    Plogin.add(user);
    contraseña.setText("Contraseña: ");
    contraseña.setBounds(250,295,280,20);
    contraseña.setForeground(Color.white);
    contraseña.setFont(new Font("Serif",Font.BOLD,22));
    Plogin.add(contraseña);
    password.setFont(new Font("Serif",Font.BOLD,22));
    password.setForeground(Color.decode("#BCE081"));
    password.setBounds(140,325,420,50);
    Plogin.add(password);
    BIngresar.setBounds(160,400,100,40);
    BIngresar.setText("Ingresar");
    BIngresar.setFont(new Font("Serif",Font.BOLD,12));
    Plogin.add(BIngresar);
    BCancelar.setBounds(390,400,100,40);
    BCancelar.setText("Cancelar");
    BCancelar.setFont(new Font("Serif",Font.BOLD,12));
    Plogin.add(BCancelar);
}

public void logear(usuarioSearch_201708938 buscar){
    String usuarioNombre = user.getText().trim();
   String usuarioContraseña = password.getText().trim();
    try {
        buscar.busqueda(usuarioNombre, usuarioContraseña);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(Plogin,"No existe el usuario, contacte al administrador");
    }
    switch(buscar.estadoEncontrado){
        case 1: 
            JOptionPane.showMessageDialog(Plogin,"Has ingresado", "",JOptionPane.INFORMATION_MESSAGE);
            inicio_usuario = new InicioUsuario_201708938();
            Flogin.show(false);
            inicio_usuario.FinicioUsuario.show(true);
            asignarUsuarioInfo(usuarioNombre);
            usuarioSalio();
            break;
        case 2: 
            JOptionPane.showMessageDialog(password,"Contraseña no coincide", "",JOptionPane.NO_OPTION);
            break;
        case 4: 
            JOptionPane.showMessageDialog(Plogin,"Has ingresado", "",JOptionPane.INFORMATION_MESSAGE);
            inicio_admin = new InicioAdmin_201708938();
            asignarAdmiInfo();
            Flogin.show(false);
             adminSalio();
            break;
        default:
            JOptionPane.showMessageDialog(Plogin,"Usuario no existe, ponte en contacto con el administrador", "",JOptionPane.NO_OPTION);
            break;
    }
}
//Recolectamos la data del administrador cuando salio
public void adminSalio(){
    inicio_admin.Bsalir.addActionListener(new ActionListener() {
       
        public void actionPerformed(ActionEvent ae) {
            inicio_admin.FinicioAdmin.show(false);
             recorgerAdmiInfo();
            Flogin.show(true);
        }
    });
}

public void usuarioSalio(){
    inicio_usuario.Bsalir.addActionListener(new ActionListener() {
        
        public void actionPerformed(ActionEvent ae) {
            inicio_usuario.FinicioUsuario.show(false);
            recogerUsuarioInfo();
            Flogin.show(true);
        }
    });
}

public void recorgerAdmiInfo(){
    inicio_admi_correlativo = inicio_admin.correlativo;
    inicio_admi_correlativo_creaBibliografiaL =inicio_admin.correlativo_creaBibliografiaL;
    inicio_admin_correlativo_creaBibliografiaR=inicio_admin.correlativo_creaBibliografiaR;
    inicio_admin_correlativo_creaBibliografiaT = inicio_admin.correlativo_creaBibliografiaT;
    biblioteca = inicio_admin.creandoBibliografía;
    buscar = inicio_admin.creandoUsuario;
}

public void asignarAdmiInfo(){
    inicio_admin.correlativo = inicio_admi_correlativo;
    inicio_admin.correlativo_creaBibliografiaL = inicio_admi_correlativo_creaBibliografiaL;
    inicio_admin.correlativo_creaBibliografiaR = inicio_admin_correlativo_creaBibliografiaR;
    inicio_admin.correlativo_creaBibliografiaT = inicio_admin_correlativo_creaBibliografiaT;
    inicio_admin.creandoUsuario = buscar;
    inicio_admin.creandoBibliografía = biblioteca;
}

public void recogerUsuarioInfo(){
    biblioteca = inicio_usuario.libreria;
    prestamo = inicio_usuario.prestamito;
    correlativo_prestamo_usuario = inicio_usuario.correlativo_prestamo;
    buscar = inicio_usuario.busqueda;
}

public void asignarUsuarioInfo(String usuarioId){
    inicio_usuario.libreria = biblioteca;
    inicio_usuario.prestamito = prestamo;
    inicio_usuario.correlativo_prestamo = correlativo_prestamo_usuario;
    inicio_usuario.usuarioId = usuarioId;
    inicio_usuario.busqueda = buscar;
}

}
