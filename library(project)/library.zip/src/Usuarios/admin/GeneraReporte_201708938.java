package Usuarios.admin;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GeneraReporte_201708938 {
    JFrame FgeneraReporte = new JFrame();
    JPanel PgeneraReporte = new JPanel();
    JLabel nReporte = new JLabel();
    JComboBox Creporte = new JComboBox();
    JButton Bgenerar = new JButton();
    JButton Bregresar = new JButton();
    JTable TablaReporte;
    JScrollPane STablaReporte = new JScrollPane();
    
    String [] columnas= {"Usuario/Autor","Id/Titulo","Bibliografias prestadas/buscadas"};
    //recoger info
    String [][] datousuario;
    String []numero;
    
    
    DefaultTableModel modeloTablaRepote;

    public GeneraReporte_201708938() {
    configurarGeneraReporte();
    llenarCReporte();
    FgeneraReporte.show(true);
    }
    
    
    public void configurarGeneraReporte(){
         FgeneraReporte.setSize(900,750);
    FgeneraReporte.setTitle("Genera Reportes ");
    FgeneraReporte.setLocationRelativeTo(null);
    FgeneraReporte.setDefaultCloseOperation(FgeneraReporte.EXIT_ON_CLOSE);
    FgeneraReporte.add(PgeneraReporte);
    PgeneraReporte.setBounds(0,0,FgeneraReporte.getWidth(),FgeneraReporte.getHeight());
    PgeneraReporte.setLayout(null);
    PgeneraReporte.setBackground(Color.decode("#BCE081"));
    
    nReporte.setText("Reporte: ");
    nReporte.setBounds(30,30,130,30);
    nReporte.setFont(new Font("Arial",Font.BOLD,25));
    nReporte.setForeground(Color.orange);
    PgeneraReporte.add(nReporte);
    Creporte.setBounds(180,30,250,50);
    PgeneraReporte.add(Creporte);
    Bgenerar.setText("Generar");
    Bgenerar.setBounds(520,30,100,50);
    PgeneraReporte.add(Bgenerar);
    Bregresar.setText("Regresar");
    Bregresar.setBounds(680,30,100,50);
    PgeneraReporte.add(Bregresar);  
    modeloTablaRepote = new DefaultTableModel(null,columnas);
    TablaReporte = new JTable(modeloTablaRepote);
    STablaReporte.setViewportView(TablaReporte);
    STablaReporte.setBounds(80,130,650,500);
    PgeneraReporte.add(STablaReporte);
    }
   
    public void SegunOpcionCreporte(Usuarios.usuarioSearch_201708938 busqueda,Biblioteca.Biblioteca_201708938 libreria){
        if (Creporte.getSelectedItem().equals("Usuarios que han prestado")) {
            opcionUsuariosPrestados(busqueda);
        }else if (Creporte.getSelectedItem().equals("Libros más prestados")) {
            opcionLibrosPrestados(libreria);
        }else if(Creporte.getSelectedItem().equals("Revistas más prestadas")){
            opcionRevistasPrestados(libreria);
        }else if (Creporte.getSelectedItem().equals("Tesis más prestadas")) {
            opcionTesisPrestados(libreria);
        }else if (Creporte.getSelectedItem().equals("Bibliografias más buscadas")) {
            opcionBibliografiaPrestados(libreria);
        }
    }
    
    public void llenarCReporte(){
        Creporte.addItem("Usuarios que han prestado");
        Creporte.addItem("Libros más prestados");
        Creporte.addItem("Revistas más prestadas");
        Creporte.addItem("Bibliografias más buscadas");
        Creporte.addItem("Tesis más prestadas");
    }
    
    public void opcionUsuariosPrestados(Usuarios.usuarioSearch_201708938 busqueda){
        
  //      System.out.println(busqueda.usuarioLista[0].numeroPrestamo + "Prestamo 0");
    //    System.out.println(busqueda.usuarioLista[1].numeroPrestamo + "Prestamo 1");
//        System.out.println(busqueda.usuarioLista[2].numeroPrestamo + "Prestamo 0");
        limpiarTabla();
        for (int i = 0; i <=busqueda.contador_usuario; i++) {
                try {
                if (busqueda.usuarioLista[i].numeroPrestamo >0) {
                    try {
                        String userId = busqueda.usuarioLista[i].getCUI();
                        String nombre = busqueda.usuarioLista[i].getNombre();
                        int numeroPrestado = busqueda.usuarioLista[i].numeroPrestamo;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }    
                } catch (Exception e) {
                    continue;
                }
        }
        //Tomamos datos de la tabla
        datousuario = new String[modeloTablaRepote.getRowCount()][3];
        numero = new String[modeloTablaRepote.getRowCount()];
        for (int i = 0; i < modeloTablaRepote.getRowCount(); i++) {
            String nombre = modeloTablaRepote.getValueAt(i, 0).toString();
            String id = modeloTablaRepote.getValueAt(i, 1).toString();
            String numero = modeloTablaRepote.getValueAt(i, 2).toString();
            this.numero[i] = numero;
            datousuario[i][0]= nombre;
            datousuario[i][1]= id;
            datousuario[i][2]= numero;
           
        }
        limpiarTabla();
        for (int i = 1; i < numero.length; i++) {
                for (int j = 0; j < numero.length-1; j++) {
                    try {
                    if (numero[j].toString().compareTo(numero[j+1].toString())<0) {
                        String temp = numero[j].toString();
                        numero[j] = numero[j+1];
                        numero[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
        }
        
         for (int i = 0; i <=numero.length; i++) {
            try{
                for (int j = 0; j <=numero.length; j++) {
                     if (datousuario[j][2].equals(numero[i])) {
            String a= datousuario[j][0];
            String b= datousuario[j][1];
            String c = datousuario[j][2];
            
            String []algo ={a,b,c};
            
           modeloTablaRepote.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length");
            System.out.println("eliminando "+i);
        }
        }   
        verificarDato();
        }
    public void opcionLibrosPrestados(Biblioteca.Biblioteca_201708938 libreria){
        limpiarTabla();
        for (int i = 0; i <=libreria.posición_Clibro; i++) {
                try {
                if (libreria.libro[i].numeroDePrestado >0) {
                    try {
                        String userId = libreria.libro[i].autor;
                        String nombre = libreria.libro[i].título;
                        int numeroPrestado = libreria.libro[i].numeroDePrestado;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }    
                } catch (Exception e) {
                    continue;
                }
        }
        //Tomamos datos de la tabla
        datousuario = new String[modeloTablaRepote.getRowCount()][3];
        numero = new String[modeloTablaRepote.getRowCount()];
        for (int i = 0; i < modeloTablaRepote.getRowCount(); i++) {
            String nombre = modeloTablaRepote.getValueAt(i, 0).toString();
            String id = modeloTablaRepote.getValueAt(i, 1).toString();
            String numero = modeloTablaRepote.getValueAt(i, 2).toString();
            this.numero[i] = numero;
            datousuario[i][0]= nombre;
            datousuario[i][1]= id;
            datousuario[i][2]= numero;
           
        }
        limpiarTabla();
        for (int i = 1; i < numero.length; i++) {
                for (int j = 0; j < numero.length-1; j++) {
                    try {
                    if (numero[j].toString().compareTo(numero[j+1].toString())<0) {
                        String temp = numero[j].toString();
                        numero[j] = numero[j+1];
                        numero[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
        }
        
         for (int i = 0; i <=numero.length; i++) {
            try{
                for (int j = 0; j <=numero.length; j++) {
                     if (datousuario[j][2].equals(numero[i])) {
            String a= datousuario[j][0];
            String b= datousuario[j][1];
            String c = datousuario[j][2];
            
            String []algo ={a,b,c};
            
           modeloTablaRepote.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length");
            System.out.println("eliminando "+i);
        }
        }  
         verificarDato();
        }
    
     public void opcionRevistasPrestados(Biblioteca.Biblioteca_201708938 libreria){
        limpiarTabla();
        for (int i = 0; i <=libreria.posición_Crevista; i++) {
                try {
                if (libreria.revista[i].numeroDePrestado >0) {
                    try {
                        String userId = libreria.revista[i].autor;
                        String nombre = libreria.revista[i].título;
                        int numeroPrestado = libreria.revista[i].numeroDePrestado;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }    
                } catch (Exception e) {
                    continue;
                }
        }
        //Tomamos datos de la tabla
        datousuario = new String[modeloTablaRepote.getRowCount()][3];
        numero = new String[modeloTablaRepote.getRowCount()];
        for (int i = 0; i <modeloTablaRepote.getRowCount(); i++) {
            String nombre = modeloTablaRepote.getValueAt(i, 0).toString();
            String id = modeloTablaRepote.getValueAt(i, 1).toString();
            String numero = modeloTablaRepote.getValueAt(i, 2).toString();
            this.numero[i] = numero;
            datousuario[i][0]= nombre;
            datousuario[i][1]= id;
            datousuario[i][2]= numero;
           
        }
        limpiarTabla();
        for (int i = 1; i < numero.length; i++) {
                for (int j = 0; j < numero.length-1; j++) {
                    try {
                    if (numero[j].toString().compareTo(numero[j+1].toString())<0) {
                        String temp = numero[j].toString();
                        numero[j] = numero[j+1];
                        numero[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
        }
        
         for (int i = 0; i <=numero.length; i++) {
            try{
                for (int j = 0; j <=numero.length; j++) {
                     if (datousuario[j][2].equals(numero[i])) {
            String a= datousuario[j][0];
            String b= datousuario[j][1];
            String c = datousuario[j][2];
            
            String []algo ={a,b,c};
            
           modeloTablaRepote.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length");
            System.out.println("eliminando "+i);
        }
        }   
         verificarDato();
    }
    
     public void opcionTesisPrestados(Biblioteca.Biblioteca_201708938 libreria){
        limpiarTabla();
        for (int i = 0; i <=libreria.posición_Ctesis; i++) {
                try {
                if (libreria.tesis[i].numeroDePrestado >0) {
                    try {
                        String userId = libreria.tesis[i].autor;
                        String nombre = libreria.tesis[i].título;
                        int numeroPrestado = libreria.tesis[i].numeroDePrestado;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }    
                } catch (Exception e) {
                    continue;
                }
        }
        //Tomamos datos de la tabla
        datousuario = new String[modeloTablaRepote.getRowCount()][3];
        numero = new String[modeloTablaRepote.getRowCount()];
        for (int i = 0; i <modeloTablaRepote.getRowCount(); i++) {
            String nombre = modeloTablaRepote.getValueAt(i, 0).toString();
            String id = modeloTablaRepote.getValueAt(i, 1).toString();
            String numero = modeloTablaRepote.getValueAt(i, 2).toString();
            this.numero[i] = numero;
            datousuario[i][0]= nombre;
            datousuario[i][1]= id;
            datousuario[i][2]= numero;
           
        }
        limpiarTabla();
        for (int i = 1; i < numero.length; i++) {
                for (int j = 0; j < numero.length-1; j++) {
                    try {
                    if (numero[j].toString().compareTo(numero[j+1].toString())<0) {
                        String temp = numero[j].toString();
                        numero[j] = numero[j+1];
                        numero[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
        }
        
         for (int i = 0; i <=numero.length; i++) {
            try{
                for (int j = 0; j <=numero.length; j++) {
                     if (datousuario[j][2].equals(numero[i])) {
            String a= datousuario[j][0];
            String b= datousuario[j][1];
            String c = datousuario[j][2];
            
            String []algo ={a,b,c};
            
           modeloTablaRepote.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length");
            System.out.println("eliminando "+i);
        }
        }   
         verificarDato();
    }
     
     public void opcionBibliografiaPrestados(Biblioteca.Biblioteca_201708938 libreria){
        limpiarTabla();
        int total = libreria.posición_Clibro+libreria.posición_Crevista+libreria.posición_Ctesis;
        for (int i = 0; i <=total; i++) {
                try {
                if (libreria.tesis[i].numeroDeBusqueda >0) {
                    try {
                        String userId = libreria.tesis[i].autor;
                        String nombre = "Revista";
                        int numeroPrestado = libreria.tesis[i].numeroDeBusqueda;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }
                if (libreria.revista[i].numeroDeBusqueda >0) {
                    try {
                        String userId = libreria.revista[i].autor;
                        String nombre = "Revista";
                        int numeroPrestado = libreria.revista[i].numeroDeBusqueda;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                }
                if (libreria.libro[i].numeroDePrestado >0) {
                    try {
                        String userId = libreria.libro[i].autor;
                        String nombre = "Libro";
                        int numeroPrestado = libreria.libro[i].numeroDeBusqueda;
                        Object datos[] = {nombre,userId,numeroPrestado};
                        modeloTablaRepote.addRow(datos);
                        TablaReporte.repaint();
                        System.out.println(userId+"NP "+numeroPrestado);
                    } catch (Exception e) {
                        System.out.println(""+e);
                        continue;
                        
                    }
                } 
                } catch (Exception e) {
                    continue;
                }
        }
        //Tomamos datos de la tabla
        datousuario = new String[modeloTablaRepote.getRowCount()][3];
        numero = new String[modeloTablaRepote.getRowCount()];
        for (int i = 0; i < modeloTablaRepote.getRowCount(); i++) {
            String nombre = modeloTablaRepote.getValueAt(i, 0).toString();
            String id = modeloTablaRepote.getValueAt(i, 1).toString();
            String numero = modeloTablaRepote.getValueAt(i, 2).toString();
            this.numero[i] = numero;
            datousuario[i][0]= nombre;
            datousuario[i][1]= id;
            datousuario[i][2]= numero;
           
        }
        limpiarTabla();
        for (int i = 1; i < numero.length; i++) {
                for (int j = 0; j < numero.length-1; j++) {
                    try {
                    if (numero[j].toString().compareTo(numero[j+1].toString())<0) {
                        String temp = numero[j].toString();
                        numero[j] = numero[j+1];
                        numero[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
        }
        
         for (int i = 0; i <=numero.length; i++) {
            try{
                for (int j = 0; j <=numero.length; j++) {
                     if (datousuario[j][2].equals(numero[i])) {
            String a= datousuario[j][0];
            String b= datousuario[j][1];
            String c = datousuario[j][2];
            
            String []algo ={a,b,c};
            
           modeloTablaRepote.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length");
            System.out.println("eliminando "+i);
        }
        }
         verificarDato();
    }
    
    
     public void limpiarTabla(){
        for (int i = 0; i < modeloTablaRepote.getRowCount(); i++) {
            modeloTablaRepote.removeRow(i);
            i=-1;
        }
       // modeloTabla.setRowCount(0);
        TablaReporte.repaint();
    }
     
     public void verificarDato(){
        for (int i = 0; i < modeloTablaRepote.getRowCount(); i++) {
            String a =modeloTablaRepote.getValueAt(i,1).toString().trim();
            for (int j = i+1; j < modeloTablaRepote.getRowCount(); j++) {
                if (a.equals(modeloTablaRepote.getValueAt(j, 1).toString().trim())) {
                
                    try {
                     modeloTablaRepote.removeRow(j); 
                        System.out.println("Se elimino "+j);
                    } catch (Exception e) {
                    
                    }
            }
            }
            
        }
        
    }
    }
    