
package Usuarios.admin;

import Usuarios.usuarioSearch_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.beans.PropertyChangeListener;
import javax.swing.*;

public class CreaUsuario_201708938 {

JFrame FcreaUsuario = new JFrame();
JPanel PcreaUsuario = new JPanel();
JLabel nId = new JLabel();
JLabel nPassword = new JLabel();
JLabel nNombre = new JLabel();
JLabel nApellido = new JLabel();
JLabel nRol = new JLabel();
JTextField Tid = new JTextField();
JTextField Tpassword = new JTextField();
JTextField Tnombre = new JTextField();
JTextField Tapellido = new JTextField();
JTextField Trol = new JTextField();
JButton BcreaUsuario = new JButton();
JButton Bcancelar = new JButton();

JLabel imgUser = new JLabel();
ImageIcon IconUser = new ImageIcon(getClass().getResource("/imagenes/usuarios_201708938.png"));


public int Posición_creando = 0;

    public CreaUsuario_201708938() {
    configurarUsuario();
    FcreaUsuario.show(true);
    limitarField();
    
    }
    
public void configurarUsuario(){
    FcreaUsuario.setSize(750,525);
    FcreaUsuario.setLocationRelativeTo(null);
    FcreaUsuario.setTitle("Crear Usuario");
    FcreaUsuario.setDefaultCloseOperation(FcreaUsuario.EXIT_ON_CLOSE);
    FcreaUsuario.add(PcreaUsuario);
    PcreaUsuario.setLayout(null);
    PcreaUsuario.setBounds(0,0,FcreaUsuario.getWidth(),FcreaUsuario.getHeight());
    PcreaUsuario.setBackground(Color.decode("#BCE081"));
    
    imgUser.setIcon(IconUser);
    imgUser.setBounds(280,20,100,80);
    PcreaUsuario.add(imgUser);
    
    nId.setText("ID(CUI):");
    nId.setBounds(10,115,90,30);
    nId.setFont(new Font("Serif",Font.BOLD,20));
    nId.setForeground(Color.orange);
    PcreaUsuario.add(nId);
    Tid.setBounds(110,115,180,40);
    Tid.setFont(new Font("Serif",Font.BOLD,15));
    PcreaUsuario.add(Tid);
    nRol.setText("Rol");
    nRol.setBounds(365,115,90,30);
    nRol.setFont(new Font("Serif",Font.BOLD,20));
    nRol.setForeground(Color.orange);
    PcreaUsuario.add(nRol);
    Trol.setBounds(420,115,180,40);
    Trol.setFont(new Font("Serif",Font.BOLD,15));
    PcreaUsuario.add(Trol);
    nNombre.setText("Nombre:");
    nNombre.setBounds(10,225,90,30);
    nNombre.setFont(new Font("Serif",Font.BOLD,20));
    nNombre.setForeground(Color.orange);
    PcreaUsuario.add(nNombre);
    Tnombre.setBounds(110,225,180,40);
    Tnombre.setFont(new Font("Serif",Font.BOLD,15));
    PcreaUsuario.add(Tnombre);
    nApellido.setText("Apellido:");
    nApellido.setBounds(365,225,90,30);
    nApellido.setFont(new Font("Serif",Font.BOLD,20));
    nApellido.setForeground(Color.orange);
    PcreaUsuario.add(nApellido);
    Tapellido.setBounds(450,225,180,40);
    Tapellido.setFont(new Font("Serif",Font.BOLD,15));
    PcreaUsuario.add(Tapellido);
    nPassword.setText("Contraseña:");
    nPassword.setBounds(10,320,120,30);
    nPassword.setFont(new Font("Serif",Font.BOLD,20));
    nPassword.setForeground(Color.orange);
    PcreaUsuario.add(nPassword);
    Tpassword.setBounds(120,320,180,40);
    Tpassword.setFont(new Font("Serif",Font.BOLD,15));
    PcreaUsuario.add(Tpassword);
    BcreaUsuario.setBounds(190,420,100,40 );
    BcreaUsuario.setText("Crear");
    PcreaUsuario.add(BcreaUsuario);
    Bcancelar.setBounds(375,420,100,40 );
    Bcancelar.setText("Cancelar");
    PcreaUsuario.add(Bcancelar);
    
}

    public void limitarField(){
     Tid.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tid.getText().length()>13){
                e.consume();
                JOptionPane.showMessageDialog(PcreaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
     Tnombre.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tnombre.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PcreaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    Tpassword.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tpassword.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PcreaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    Tapellido.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tapellido.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PcreaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    }
    public void Creando(Usuarios.usuarioSearch_201708938 creandoUsuario){
        //Posición_creando = Posición_creando + creandoUsuario.getContador_usuario();
        //boolean si_no;
        comprobarRellenado();
        comprobarDatoRepetido(creandoUsuario);
        String cui = Tid.getText().trim();
        String nombre = Tnombre.getText().trim();
        String apellido = Tapellido.getText().trim();
        String rol = Trol.getText().trim();
        String contraseña = Tpassword.getText().trim();
        //comprobarDatoRepetido(creandoUsuario);
        int option = JOptionPane.showConfirmDialog(PcreaUsuario,"¿Deseas crear el usuario: " + cui +" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        switch(option){
            case 1:
                creandoUsuario.setContador_usuario(Posición_creando);
                creandoUsuario.crearUsuario(cui, nombre, apellido, rol, contraseña);
                limpiar();
                break;
            case 2: 
                limpiar();
                Posición_creando = Posición_creando -1;
                break;
            default:
                break;
        }        
    }
    
    public void limpiar(){
        Tid.setText(null);
        Tnombre.setText(null);
        Tapellido.setText(null);
        Trol.setText(null);
        Tpassword.setText(null);
    }
    
    public void comprobarRellenado(){
        boolean estadoLlenado = true;
        do{
        if(Tid.getText().equals("")){
            Tid.setText(JOptionPane.showInputDialog(Tid,"Ingresa un ID,por favor"));
        }else if(Tnombre.getText().equals("")){
            Tnombre.setText(JOptionPane.showInputDialog(Tnombre,"Ingresa un nombre,por favor"));
            
        }else if(Tapellido.getText().equals("")){
            Tapellido.setText(JOptionPane.showInputDialog(Tapellido,"Ingresa un apellido,por favor"));;
        }else if(Trol.getText().equals("")){
            Trol.setText(JOptionPane.showInputDialog(Trol,"Ingresa un rol,por favor"));
        }else if(Tpassword.getText().equals("")){
            Tpassword.setText(JOptionPane.showInputDialog(Tpassword,"Ingresa una contraseña,por favor"));
        }else{
            estadoLlenado = false;
        }
        }while(estadoLlenado);
    }
    
    public void comprobarDatoRepetido(usuarioSearch_201708938 creandoUsuario){
        for (int i = 0; i < creandoUsuario.usuarioLista.length; i++) {
            try {
             if (Tid.getText().trim().equals(creandoUsuario.usuarioLista[i].getCUI())) {
                Tid.setText(JOptionPane.showInputDialog(Tid,"Usuario existente, Ingresa otro nombre de usuario,por favor"));
            }   
            } catch (Exception e) {
               continue;
            }
        }
    }
    
}
