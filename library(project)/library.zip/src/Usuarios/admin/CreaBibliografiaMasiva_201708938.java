
package Usuarios.admin;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
public class CreaBibliografiaMasiva_201708938 {
    
JFrame FcreaBibliografiaMasiva = new JFrame();
JPanel PcreaBibliografiaMasiva = new JPanel();
JButton Bcargar = new JButton();
JButton Bregresar = new JButton();
JLabel nCargar = new JLabel();
JLabel nResultados = new JLabel();
JTextArea AcargaMasiva = new JTextArea();
JTable TablaResultados;
DefaultTableModel modeloTabla;

JScrollPane STablaResultados = new JScrollPane();
JScrollPane SAcargaMasiva = new JScrollPane();

String [] columna = {"Tipo","Autor","Titulo","Edición","Palabras Clave","Descripción","Temas","Copias","Disponibles","Otros Datos: "};
String [] datos;
int Posición_creandoLibro;
int Posición_creandoRevista;
int Posición_creandoTesis;

    public CreaBibliografiaMasiva_201708938() {
        
        configurarCargaMasiva();
        FcreaBibliografiaMasiva.show(true);
    }


public void configurarCargaMasiva(){
    FcreaBibliografiaMasiva.setSize(1200,850);
    FcreaBibliografiaMasiva.setLocationRelativeTo(null);
    FcreaBibliografiaMasiva.setTitle("Carga Masiva");
    FcreaBibliografiaMasiva.setDefaultCloseOperation(FcreaBibliografiaMasiva.EXIT_ON_CLOSE);
    FcreaBibliografiaMasiva.add(PcreaBibliografiaMasiva);
    PcreaBibliografiaMasiva.setLayout(null);
    PcreaBibliografiaMasiva.setBounds(0,0,PcreaBibliografiaMasiva.getWidth(),PcreaBibliografiaMasiva.getHeight());
    PcreaBibliografiaMasiva.setBackground(Color.decode("#BCE081"));
    nCargar.setText("Cargar");
    nCargar.setBounds(30,30,100,50);
    nCargar.setFont(new Font("Serif",Font.BOLD, 28));
    nCargar.setForeground(Color.orange);
    PcreaBibliografiaMasiva.add(nCargar);
    nResultados.setText("Resultados: ");
    nResultados.setFont(new Font("Serif",Font.BOLD, 28));
    nResultados.setForeground(Color.orange);
    nResultados.setBounds(650,30,200,50);
    PcreaBibliografiaMasiva.add(nResultados);
    SAcargaMasiva.setViewportView(AcargaMasiva);
    SAcargaMasiva.setPreferredSize(new Dimension(400,650));
    SAcargaMasiva.setBounds(30,100,600,450);
    PcreaBibliografiaMasiva.add(SAcargaMasiva);
    modeloTabla = new DefaultTableModel(null,columna);
    TablaResultados = new JTable(modeloTabla);
    STablaResultados.setViewportView(TablaResultados);
    STablaResultados.setBounds(650,100,500,650);
    STablaResultados.setPreferredSize(new Dimension(1200,650));
    PcreaBibliografiaMasiva.add(STablaResultados);
    Bcargar.setText("Cargar");
    Bcargar.setBounds(150,590,150,50);
    PcreaBibliografiaMasiva.add(Bcargar);
    Bregresar.setText("Regresar");
    Bregresar.setBounds(350,590,150,50);
    PcreaBibliografiaMasiva.add(Bregresar);
}

 public void creandoLibro(Biblioteca.Biblioteca_201708938 libreria){
        String título = datos [2];
        String autor = datos[1];
        String [] Palabras_claves=datos[4].split(",");
        int edición = Integer.parseInt(datos[3]) ;
        String descripción = datos[5]; 
        String [] temas = datos[6].split(",");
        int copias = Integer.parseInt(datos[7]);
        int disponibles = Integer.parseInt(datos[8]);

        String palabrasClavesTabla = datos[4];
        String temasTabla= datos[6];
        
                libreria.setPosición_Clibro(Posición_creandoLibro);
                libreria.crearLibro(autor, título, edición, Palabras_claves, descripción, temas, copias, disponibles);
                Object[] items ={"Libro",autor,título,edición,palabrasClavesTabla,descripción,temasTabla,copias,disponibles};
                modeloTabla.addRow(items);
                /*        
                limpiar();
       
                limpiar();
                Posición_creandoLibro = Posición_creandoLibro -1;*/   
    }
 
 public void creandoRevista(Biblioteca.Biblioteca_201708938 libreria){
        String título = datos [2];
        String autor = datos[1];
        String [] Palabras_claves = datos[4].split(",");
        int edición = Integer.parseInt(datos[3]) ;
        String descripción = datos[5]; 
        String [] temas = datos[6].split(",");
        int copias = Integer.parseInt(datos[9]);
        int disponibles = Integer.parseInt(datos[10]);
        String frecuenciaActual = datos[7];
        int ejemplares = Integer.parseInt(datos[8]);
        
        String palabrasClavesTabla = datos[4];
        String temasTabla = datos[6];
        try {
            
        
                libreria.setPosición_Crevista(Posición_creandoRevista);
                libreria.crearRevista(autor, título, edición, descripción,frecuenciaActual, copias, temas, Palabras_claves, copias, disponibles);
                Object[] items ={"Revista",autor,título,edición,palabrasClavesTabla,descripción,temasTabla,copias,disponibles,"Frecuencia "+frecuenciaActual+" Ejemplar: "+ejemplares};
                modeloTabla.addRow(items);
                /*    limpiar();
                TfrecuenciaActual.setText(null);
             
                limpiar();
                TfrecuenciaActual.setText(null);
                Posición_creandoRevista = Posición_creandoRevista -1;
              */
        }
         catch (Exception e) {
        }        
    }
 
  public void creandoTesis(Biblioteca.Biblioteca_201708938 libreria){
        String título = datos [2];
        String autor = datos[1];
        String [] Palabras_claves = datos[4].split(",");
        int edición = Integer.parseInt(datos[3]) ;
        String descripción = datos[5]; 
        String [] temas = datos[6].split(",");
        int copias = Integer.parseInt(datos[8]);
        int disponibles = Integer.parseInt(datos[9]);
        String areaAcademica = datos[7];
      
        String palabrasClavesTabla = datos[4];
        String temasTabla = datos[6];
        try {
        
                libreria.setPosición_Ctesis(Posición_creandoTesis);
                libreria.crearTesis(autor, título, Palabras_claves,areaAcademica, temas, descripción, edición, copias, disponibles);
                Object[] items ={"Tesis",autor,título,edición,Palabras_claves,descripción,temasTabla,copias,disponibles,"Area "+areaAcademica};
                modeloTabla.addRow(items);
                /*   limpiar();
                TareaAcademica.setText(null);
               */ 
        } catch (Exception e) {
            
        }
    }
  
  public void vaciar(){
      AcargaMasiva.setText("");
  }
  
}
