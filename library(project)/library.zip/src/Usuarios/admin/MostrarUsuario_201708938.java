package Usuarios.admin;
import Usuarios.usuarioSearch_201708938;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class MostrarUsuario_201708938 {

    JFrame FMostrarUsuario = new JFrame();
    JPanel PMostrarUsuario = new JPanel();
    JLabel nOrden = new JLabel();
    JComboBox Corden = new JComboBox();
    JButton Bregresar = new JButton();
    
    JPanel PtablaMostrar = new JPanel();
    JTable tablaUsuario;
    JScrollPane scrollTabla = new JScrollPane();
    
    public Object [][] datos;
    private String [] columna = {"ID","Nombre","Apellido","Rol"};

    DefaultTableModel modeloTabla;
    
    String []ids;
    
    public MostrarUsuario_201708938(usuarioSearch_201708938 busqueda) {
        llenarCorden();
        ConfigurarMostrar(busqueda);
        ordenSegúnCorden(busqueda);
    
    FMostrarUsuario.show(true);
    }
    
    
    
    
    public void ConfigurarMostrar(usuarioSearch_201708938 busqueda){
            FMostrarUsuario.setSize(950,750);
            FMostrarUsuario.setLocationRelativeTo(null);
            FMostrarUsuario.setTitle("Mostrar Usuarios");
            FMostrarUsuario.add(PMostrarUsuario);
            FMostrarUsuario.setDefaultCloseOperation(FMostrarUsuario.EXIT_ON_CLOSE);
            PMostrarUsuario.setBounds(0, 0,FMostrarUsuario.getWidth(),FMostrarUsuario.getHeight());
            PMostrarUsuario.setBackground(Color.decode("#BCE081"));
            PMostrarUsuario.setLayout(null);
            nOrden.setText("Ordenar: ");
            nOrden.setBounds(50,60,120,50);
            nOrden.setFont(new Font("Serif",Font.BOLD,25));
            nOrden.setForeground(Color.white);
            PMostrarUsuario.add(nOrden);
            Corden.setBounds(240,60,230,50);
            Corden.setFont(new Font("Serif",Font.BOLD,15));
            PMostrarUsuario.add(Corden);
            Bregresar.setBounds(580,60,230,50);
            Bregresar.setText("Regresar ");
            Bregresar.setFont(new Font("Serif",Font.BOLD,23));
            Bregresar.setForeground(Color.yellow);
            PMostrarUsuario.add(Bregresar);
          //  llenarTabla(busqueda); 
           try {
            probarAscendente(busqueda);
        } catch (Exception e) {
        }
            modeloTabla = new DefaultTableModel(datos,columna);
            tablaUsuario = new  JTable(modeloTabla);
            espaciarNull(busqueda);
            scrollTabla.setViewportView(tablaUsuario);
            scrollTabla.setBackground(Color.yellow);
            scrollTabla.setBounds(40,200,850,420);
            scrollTabla.setPreferredSize(new Dimension(600,250));   
            PMostrarUsuario.add(scrollTabla);
    }
    public void llenarTabla(usuarioSearch_201708938 busqueda){
        datos = new Object[busqueda.contador_usuario+1][4];
        ids = new String[busqueda.contador_usuario+1];
        for (int i = 1; i <=busqueda.contador_usuario+1; i++) {
            try{
            if (!busqueda.usuarioLista[i].getCUI().equals(null)) {
            
            ids[i]=busqueda.usuarioLista[i].getCUI();
            }else{
                System.out.println("no found a");
            }
            
        }catch(Exception e){
            System.out.println("no found");
            System.out.println("eliminando "+i);
        }

        }
    }
    
    public void espaciarNull(usuarioSearch_201708938 busqueda){
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            for (int j = 0; j < modeloTabla.getColumnCount(); j++) {
                try{
                if (!modeloTabla.getValueAt(i, j).equals(busqueda.usuarioLista[i].equals(null))) {
                }}catch(Exception e){
                    try {
                        System.out.println("eliminamos? "+i);
                     modeloTabla.removeRow(i);
                    } catch (Exception ev) {
                    }

                }
            }
        }
    }
    
    public void llenarCorden(){
        Corden.addItem("Ascendentemente");
        Corden.addItem("Descendentemente");
    }
    public void ordenSegúnCorden(usuarioSearch_201708938 busqueda){
        Corden.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                limpiarTabla();
                tablaUsuario.repaint();
                probarAscendente(busqueda);
                probarDescendente(busqueda);
            }
        });
    }
    
    public void probarAscendente(usuarioSearch_201708938 busqueda){
        llenarTabla(busqueda);
        if (Corden.getSelectedItem().equals("Ascendentemente")) {
            for (int i = 1; i < ids.length; i++) {
                for (int j = 1; j < ids.length-1; j++) {
                    try {
                    if (ids[j].toString().compareTo(ids[j+1].toString())>0) {
                        String temp = ids[j].toString();
                        ids[j] = ids[j+1];
                        ids[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
        }
        llenarDatosTabla(busqueda);
        for (int i = 1; i < 4; i++) {
            try {
                System.out.println("Demosle " + ids[i]);
            } catch (Exception e) {
            
            }
    
        }
    }
    
    public void probarDescendente(usuarioSearch_201708938 busqueda){ 
        llenarTabla(busqueda);
        String temp;
        if (Corden.getSelectedItem().equals("Descendentemente")) {
          for (int i = 1; i <ids.length; i++) {
                for (int j = 1; j < ids.length-1; j++) {
                    try {
                    if ((ids[j].compareTo(ids[j+1]))<0) {
                         temp = ids[j];
                        ids[j] = ids[j+1];
                        ids[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
          
        }
         limpiarTabla();
        llenarDatosTabla(busqueda);
        for (int i = 1; i < ids.length; i++) {
            try {
                System.out.println("Demosle " + ids[i]);
            } catch (Exception e) {
            
            }
        
        }
    }
    
    public void llenarDatosTabla(usuarioSearch_201708938 busqueda){
     datos = new Object[busqueda.contador_usuario+1][4];
        for (int i = 1; i <=ids.length; i++) {
            try{
                for (int j = 1; j <=busqueda.contador_usuario+1; j++) {
                     if (busqueda.usuarioLista[j].getCUI().equals(ids[i])) {
            
            datos[i][0] = busqueda.usuarioLista[j].getCUI();
            String a= busqueda.usuarioLista[j].getCUI();
            datos[i][1]= busqueda.usuarioLista[j].getNombre();
            String b= busqueda.usuarioLista[j].getNombre();
            datos[i][2]= busqueda.usuarioLista[j].getApellido();
            String c = busqueda.usuarioLista[j].getApellido();
            datos[i][3]=busqueda.usuarioLista[j].getRol();
            String d =busqueda.usuarioLista[j].getRol();
            
            String []algo ={a,b,c,d};
            
           modeloTabla.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("no found");
            System.out.println("eliminando "+i);
        }
        }       
    }
    
    public void limpiarTabla(){
        for (int i = 0; i < tablaUsuario.getRowCount(); i++) {
            modeloTabla.removeRow(i);
            i-=1;
        }
        modeloTabla.setRowCount(0);
    }
}
  
