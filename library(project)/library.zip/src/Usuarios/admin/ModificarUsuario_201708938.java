
package Usuarios.admin;

import Usuarios.usuarioSearch_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;

public class ModificarUsuario_201708938 {
    
JFrame FModificaUsuario = new JFrame();
JPanel PModificaUsuario = new JPanel();
JLabel nCid = new JLabel();
JLabel nId = new JLabel();
JLabel nPassword = new JLabel();
JLabel nNombre = new JLabel();
JLabel nApellido = new JLabel();
JLabel nRol = new JLabel();
JTextField Tid = new JTextField();
JTextField Tpassword = new JTextField();
JTextField Tnombre = new JTextField();
JTextField Tapellido = new JTextField();
JTextField Trol = new JTextField();
JButton BModificaUsuario = new JButton();
JButton Bcancelar = new JButton();
JComboBox Cid = new JComboBox();
public int Posicion_modificar;

    public ModificarUsuario_201708938() {
    configurarUsuario();
    FModificaUsuario.show(true);
    limitarField();
    
    }
    
public void configurarUsuario(){
    FModificaUsuario.setSize(750,525);
    FModificaUsuario.setLocationRelativeTo(null);
    FModificaUsuario.setTitle("Modificar Usuario");
    FModificaUsuario.setDefaultCloseOperation(FModificaUsuario.EXIT_ON_CLOSE);
    FModificaUsuario.add(PModificaUsuario);
    PModificaUsuario.setLayout(null);
    PModificaUsuario.setBounds(0,0,FModificaUsuario.getWidth(),FModificaUsuario.getHeight());
    PModificaUsuario.setBackground(Color.decode("#BCE081"));
    nCid.setBounds(160,30,100,40);
    nCid.setText("Usuario ID: ");
    nCid.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(nCid);
    Cid.setBounds(260,30,180,40);
    Cid.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Cid);
    nId.setText("ID(CUI):");
    nId.setBounds(10,115,90,30);
    nId.setFont(new Font("Serif",Font.BOLD,20));
    nId.setForeground(Color.orange);
    PModificaUsuario.add(nId);
    Tid.setBounds(110,115,180,40);
    Tid.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Tid);
    nRol.setText("Rol");
    nRol.setBounds(365,115,90,30);
    nRol.setFont(new Font("Serif",Font.BOLD,20));
    nRol.setForeground(Color.orange);
    PModificaUsuario.add(nRol);
    Trol.setBounds(420,115,180,40);
    Trol.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Trol);
    nNombre.setText("Nombre:");
    nNombre.setBounds(10,225,90,30);
    nNombre.setFont(new Font("Serif",Font.BOLD,20));
    nNombre.setForeground(Color.orange);
    PModificaUsuario.add(nNombre);
    Tnombre.setBounds(110,225,180,40);
    Tnombre.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Tnombre);
    nApellido.setText("Apellido:");
    nApellido.setBounds(365,225,90,30);
    nApellido.setFont(new Font("Serif",Font.BOLD,20));
    nApellido.setForeground(Color.orange);
    PModificaUsuario.add(nApellido);
    Tapellido.setBounds(450,225,180,40);
    Tapellido.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Tapellido);
    nPassword.setText("Contraseña:");
    nPassword.setBounds(10,320,120,30);
    nPassword.setFont(new Font("Serif",Font.BOLD,20));
    nPassword.setForeground(Color.orange);
    PModificaUsuario.add(nPassword);
    Tpassword.setBounds(120,320,180,40);
    Tpassword.setFont(new Font("Serif",Font.BOLD,15));
    PModificaUsuario.add(Tpassword);
    BModificaUsuario.setBounds(190,420,100,40 );
    BModificaUsuario.setText("Modificar");
    PModificaUsuario.add(BModificaUsuario);
    Bcancelar.setBounds(375,420,100,40 );
    Bcancelar.setText("Cancelar");
    PModificaUsuario.add(Bcancelar);
   
    
}

    public void limitarField(){
     Tnombre.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tnombre.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PModificaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    Tpassword.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tpassword.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PModificaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    Tapellido.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tapellido.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PModificaUsuario,"Has llegado al límite de carácteres");
            }
        }
    });
    }
    public void Creando(usuarioSearch_201708938 busqueda,int Posición_modificar){
        //Posicion_modificar = Posicion_modificar + creandoUsuario.getContador_usuario();
        //boolean si_no;
        comprobarRellenado();
        String cui = Tid.getText().trim();
        String nombre = Tnombre.getText().trim();
        String apellido = Tapellido.getText().trim();
        String rol = Trol.getText().trim();
        String contraseña = Tpassword.getText().trim();
        int option = JOptionPane.showConfirmDialog(PModificaUsuario,"¿Deseas Modificar el usuario: " + cui +" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        switch(option){
            case 1:
               busqueda.setCorrelativo_modificar(Posición_modificar);
               busqueda.modificarUsuario(cui, nombre, apellido, rol, contraseña);
                limpiar();
                break;
            case 2: 
                limpiar();
                break;
            default:
                break;
        }        
    }
    public void limpiar(){
        Tid.setText(null);
        Tnombre.setText(null);
        Tapellido.setText(null);
        Trol.setText(null);
        Tpassword.setText(null);
    }
    
    public void comprobarRellenado(){
        boolean estadoLlenado = true;
        do{
        if(Tid.getText().equals("")){
            Tid.setText(JOptionPane.showInputDialog(Tid,"Ingresa un ID,por favor"));
        }else if(Tnombre.getText().equals("")){
            Tnombre.setText(JOptionPane.showInputDialog(Tnombre,"Ingresa un nombre,por favor"));
            
        }else if(Tapellido.getText().equals("")){
            Tapellido.setText(JOptionPane.showInputDialog(Tapellido,"Ingresa un apellido,por favor"));;
        }else if(Trol.getText().equals("")){
            Trol.setText(JOptionPane.showInputDialog(Trol,"Ingresa un rol,por favor"));
        }else if(Tpassword.getText().equals("")){
            Tpassword.setText(JOptionPane.showInputDialog(Tpassword,"Ingresa una contraseña,por favor"));
        }else{
            estadoLlenado = false;
        }
        }while(estadoLlenado);
    }
    
    public void llenarCid(usuarioSearch_201708938 busqueda){
       
        for (int i = 1; i < busqueda.usuarioLista.length; i++) {
        try {
            if (!busqueda.usuarioLista[i].getCUI().equals(null)) {
                
            
            Cid.addItem(busqueda.usuarioLista[i].getCUI());
            }else{
                continue;
            }
//mostrarDatos(busqueda);
        
        } catch (Exception e) {
           
        }
        }//mostrarDatos(busqueda);
    }
    public void vaciarCid(){
        Cid.removeAllItems();
    }
   /* 
    public void mostrarDatos(usuarioSearch busqueda){
        Cid.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                llenarCid(busqueda);
                String buscar_id = (String)Cid.getSelectedItem();
                System.out.println(buscar_id);
                buscarDatos(busqueda, buscar_id);
            }
        });
    }*/
    
    public void buscarDatos(usuarioSearch_201708938 busqueda,String buscar_id){
        
        for (int i = 1; i <= busqueda.contador_usuario; i++) {
            try {
            if (busqueda.usuarioLista[i].getCUI().equals(buscar_id)) {
               Posicion_modificar = i;
                System.out.println("Encontramos posición " + Posicion_modificar);
            }   
            
            } catch (Exception e) {
            JOptionPane.showMessageDialog(Cid,"Error de datos");
            //continue;
        }
        }
        Tid.setText(busqueda.usuarioLista[Posicion_modificar].getCUI());
        String nombre = busqueda.usuarioLista[Posicion_modificar].getNombre();
        Tnombre.setText(nombre);
        Tapellido.setText(busqueda.usuarioLista[Posicion_modificar].getApellido());
        Tpassword.setText(busqueda.usuarioLista[Posicion_modificar].getPassword());
        Trol.setText(busqueda.usuarioLista[Posicion_modificar].getRol());
        
        
    }
    
    
}
