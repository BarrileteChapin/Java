package Usuarios.admin;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;

public class ModificaBibliografia_201708938 {
    
JFrame FmodificaBibliografia = new JFrame();
JPanel PmodificaBibliografia = new JPanel();
JLabel nAutor = new JLabel();
JLabel nPalabrasClaves = new JLabel();
JLabel nTema = new JLabel();
JLabel nCopias = new JLabel();
JLabel nEdición = new JLabel();
JLabel nDescripción = new JLabel();
JLabel nTitulo = new JLabel();
JTextField Tautor = new JTextField();
JTextField TPalabrasClaves = new JTextField();
JTextField Ttemas = new JTextField();
JTextField Tcopias = new JTextField();
JTextField Tedición = new JTextField();
JButton BmodificarBibliografia = new JButton();
JButton Bcancelar = new JButton();
JTextArea Adescripción = new JTextArea();
JTextField Ttitulo = new JTextField();
JComboBox CopcionBibliografia = new JComboBox();
JLabel nOpcionBibliografía = new JLabel();
JTextField TareaAcademica = new JTextField();
JLabel nAreaAcademica = new JLabel();
JButton Bbuscar = new JButton();

JScrollPane Sdescripción = new JScrollPane(Adescripción);
JScrollPane SpalabrasClaves = new JScrollPane(TPalabrasClaves);
JScrollPane Stemas = new JScrollPane(Ttemas);

JTextField TfrecuenciaActual = new JTextField();
JLabel nFrecuenciaActual = new JLabel();

public int Posición_modificando = -1;


    public ModificaBibliografia_201708938() {
    configurarUsuario();
    FmodificaBibliografia.show(true);
    llenarCopcion();
    cambiandoForm();   
    
    }
    
public void configurarUsuario(){
    FmodificaBibliografia.setSize(750,900);
    FmodificaBibliografia.setLocationRelativeTo(null);
    FmodificaBibliografia.setTitle("Creando Bibliografia");
    FmodificaBibliografia.setDefaultCloseOperation(FmodificaBibliografia.EXIT_ON_CLOSE);
    FmodificaBibliografia.add(PmodificaBibliografia);
    PmodificaBibliografia.setLayout(null);
    PmodificaBibliografia.setBounds(0,0,FmodificaBibliografia.getWidth(),FmodificaBibliografia.getHeight());
    PmodificaBibliografia.setBackground(Color.decode("#BCE081"));
    
    nTitulo.setText("Titulo: ");
    nTitulo.setFont(new Font("Arial",Font.BOLD,25));
    nTitulo.setForeground(Color.orange);
    nTitulo.setBounds(10,30,150,20);
    PmodificaBibliografia.add(nTitulo);
    Ttitulo.setBounds(110,30,280,30);
    PmodificaBibliografia.add(Ttitulo);
    nOpcionBibliografía.setText("Tipo: ");
    nOpcionBibliografía.setFont(new Font("Serif",Font.BOLD,25));
    nOpcionBibliografía.setForeground(Color.LIGHT_GRAY);
    nOpcionBibliografía.setBounds(480,30,100,30);
    PmodificaBibliografia.add(nOpcionBibliografía);
    CopcionBibliografia.setBounds(580,30,80,50);
    PmodificaBibliografia.add(CopcionBibliografia);
    Bbuscar.setText("Buscar");
    Bbuscar.setBounds(180,65,120,30);
    PmodificaBibliografia.add(Bbuscar);
    nAutor.setText("Autor: ");
    nAutor.setBounds(10,125,90,30);
    nAutor.setFont(new Font("Serif",Font.BOLD,20));
    nAutor.setForeground(Color.orange);
    PmodificaBibliografia.add(nAutor);
    Tautor.setBounds(110,125,300,40);
    Tautor.setFont(new Font("Serif",Font.BOLD,15));
    PmodificaBibliografia.add(Tautor);
    nEdición.setText("Edición ");
    nEdición.setBounds(480,115,90,30);
    nEdición.setFont(new Font("Serif",Font.BOLD,20));
    nEdición.setForeground(Color.orange);
    PmodificaBibliografia.add(nEdición);
    Tedición.setBounds(580,115,80,40);
    Tedición.setFont(new Font("Serif",Font.BOLD,15));
    PmodificaBibliografia.add(Tedición);
    nTema.setText("Temas: ");
    nTema.setBounds(10,225,90,30);
    nTema.setFont(new Font("Serif",Font.BOLD,20));
    nTema.setForeground(Color.orange);
    PmodificaBibliografia.add(nTema);
    Stemas.setBounds(110,225,300,40);
    Stemas.setFont(new Font("Serif",Font.BOLD,15));
    PmodificaBibliografia.add(Stemas);
    nCopias.setText("Copias: ");
    nCopias.setBounds(480,225,90,30);
    nCopias.setFont(new Font("Serif",Font.BOLD,20));
    nCopias.setForeground(Color.orange);
    PmodificaBibliografia.add(nCopias);
    Tcopias.setBounds(580,225,80,40);
    Tcopias.setFont(new Font("Serif",Font.BOLD,15));
    PmodificaBibliografia.add(Tcopias);
    nPalabrasClaves.setText("Palabras claves: ");
    nPalabrasClaves.setBounds(10,320,160,30);
    nPalabrasClaves.setFont(new Font("Serif",Font.BOLD,20));
    nPalabrasClaves.setForeground(Color.orange);
    PmodificaBibliografia.add(nPalabrasClaves);
    SpalabrasClaves.setBounds(180,320,450,40);
    SpalabrasClaves.setFont(new Font("Serif",Font.BOLD,15));
    PmodificaBibliografia.add(SpalabrasClaves);
    BmodificarBibliografia.setBounds(190,750,100,40);
    BmodificarBibliografia.setText("Guardar ");
    PmodificaBibliografia.add(BmodificarBibliografia);
    Bcancelar.setBounds(375,750,100,40);
    Bcancelar.setText("Cancelar");
    PmodificaBibliografia.add(Bcancelar);
    
    nDescripción.setText("Descripción: ");
    nDescripción.setBounds(30,385,200,200);
    nDescripción.setFont(new Font("Serif",Font.BOLD,28));
    nDescripción.setForeground(Color.orange);
    PmodificaBibliografia.add(nDescripción);
    Sdescripción.setBounds(250,380,380,200);
    PmodificaBibliografia.add(Sdescripción);
}

public void configurarParaTesis(){
    nAreaAcademica.setText("Area academica");
    nAreaAcademica.setBounds(30,600,180,50);
    nAreaAcademica.setFont(new Font("Serif",Font.BOLD,20));
    nAreaAcademica.setForeground(Color.orange);
    PmodificaBibliografia.add(nAreaAcademica);
    TareaAcademica.setBounds(250,600,390,50);
    TareaAcademica.setFont(new Font("Serif",Font.BOLD,18));
    PmodificaBibliografia.add(TareaAcademica);
   
}
public void configurarParaRevista(){
    nFrecuenciaActual.setText("Frecuencia Actual: ");
    nFrecuenciaActual.setBounds(30,600,180,50);
    nFrecuenciaActual.setFont(new Font("Serif",Font.BOLD,20));
    nFrecuenciaActual.setForeground(Color.orange);
    PmodificaBibliografia.add(nFrecuenciaActual);
    TfrecuenciaActual.setBounds(250,600,390,50);
    TfrecuenciaActual.setFont(new Font("Serif",Font.BOLD,18));
    PmodificaBibliografia.add(TfrecuenciaActual);
    
}


    public void limitarField(){
     Tautor.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tautor.getText().length()>13){
                e.consume();
                JOptionPane.showMessageDialog(PmodificaBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
     Ttemas.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Ttemas.getText().length()>60){
                e.consume();
                JOptionPane.showMessageDialog(PmodificaBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    TPalabrasClaves.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(TPalabrasClaves.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PmodificaBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    Tcopias.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e){
            if(Tcopias.getText().length()>20){
                e.consume();
                JOptionPane.showMessageDialog(PmodificaBibliografia,"Has llegado al límite de carácteres");
            }
        }
    });
    }
    
    public void buscando(Biblioteca.Biblioteca_201708938 libreria){
        String titulo = Ttitulo.getText();
        for (int i = 0; i < libreria.libro.length; i++) {
            try {
                if (titulo.equals(libreria.libro[i].título)) {
                Posición_modificando = i;
                CopcionBibliografia.setSelectedItem("(0) Libro");
                CopcionBibliografia.setEnabled(false);
                obtenerDatosLibro(libreria);
            }
            } catch (Exception e) {
                continue;
            }
            
        }
        for (int i = 0; i < libreria.revista.length; i++) {
            try {
             if (titulo.equals(libreria.revista[i].título)) {
                Posición_modificando = i;
                CopcionBibliografia.setSelectedItem("(1) Revista");
                CopcionBibliografia.setEnabled(false);
                obtenerDatosRevista(libreria);
            }
            } catch (Exception e) {
                continue;
            }
           
        }    
        for (int i = 0; i < libreria.tesis.length; i++) {
            try {
                if (titulo.equals(libreria.tesis[i].título)) {
                Posición_modificando = i;
                CopcionBibliografia.setSelectedItem("(2) Tesis");
                CopcionBibliografia.setEnabled(false);
                obtenerDatosTesis(libreria);
            }
            } catch (Exception e) {
                continue;
            }
        }
        if (Posición_modificando==-1) {
            JOptionPane.showMessageDialog(PmodificaBibliografia,"No se encuentra una biliografia de "+titulo+"");
        }
        
    }
    public void modificarSegúnOpcion(Biblioteca.Biblioteca_201708938 libreria){
        if (CopcionBibliografia.getSelectedItem().equals("(0) Libro")) {
            modificandoLibro(libreria);
        }else if (CopcionBibliografia.getSelectedItem().equals("(1) Revista")) {
            modificandoRevista(libreria);
        }else{
            modificandoTesis(libreria);
        }
    }
    
    public void modificandoLibro(Biblioteca.Biblioteca_201708938 libreria){
        String título = Ttitulo.getText();
        String autor = Tautor.getText();
        int edición = Integer.parseInt(Tedición.getText());
        String [] temas = Ttemas.getText().split(",");
        int copias = Integer.parseInt(Tcopias.getText());
        int disponibles = Integer.parseInt(Tcopias.getText());
        String [] Palabras_claves = TPalabrasClaves.getText().split(",");
        String descripción = Adescripción.getText();
        int option = JOptionPane.showConfirmDialog(PmodificaBibliografia,"¿Deseas modificar el Libro: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        
        switch(option){
           
            case 1:
                libreria.setPosición_Clibro(Posición_modificando);
                libreria.crearLibro(autor, título, edición, Palabras_claves, descripción, temas, copias, disponibles);
                limpiar();
                break;
            case 2: 
                limpiar();
                break;
            default:
                break;
        }
    }
    
    public void modificandoRevista(Biblioteca.Biblioteca_201708938 libreria){
        String título = Ttitulo.getText();
        String autor = Tautor.getText();
        int edición = Integer.parseInt(Tedición.getText());
        String [] temas = Ttemas.getText().split(",");
        int copias = Integer.parseInt(Tcopias.getText());
        int disponibles = Integer.parseInt(Tcopias.getText());
        String [] Palabras_claves = TPalabrasClaves.getText().split(",");
        String descripción = Adescripción.getText();
        String frecuenciaActual = TfrecuenciaActual.getText();
        int option = JOptionPane.showConfirmDialog(PmodificaBibliografia,"¿Deseas modificar la Libro: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        try {
        switch(option){
           
            case 1:
                libreria.setPosición_Crevista(Posición_modificando);
                libreria.crearRevista(autor, título, edición, descripción,frecuenciaActual, copias, temas, Palabras_claves, copias, disponibles);
                limpiar();
                TfrecuenciaActual.setText(null);
                break;
            case 2: 
                limpiar();
                TfrecuenciaActual.setText(null);
                break;
            default:
                break;
        }
        } catch (Exception e) {
        }        
        
    }
    
    
    public void modificandoTesis(Biblioteca.Biblioteca_201708938 libreria){
        String título = Ttitulo.getText();
        String autor = Tautor.getText();
        int edición = Integer.parseInt(Tedición.getText());
        String [] temas = Ttemas.getText().split(",");
        int copias = Integer.parseInt(Tcopias.getText());
        int disponibles = Integer.parseInt(Tcopias.getText());
        String [] Palabras_claves = TPalabrasClaves.getText().split(",");
        String descripción = Adescripción.getText();
        String areaAcademica = TareaAcademica.getText();
        
        int option = JOptionPane.showConfirmDialog(PmodificaBibliografia,"¿Deseas modificar la Tesis: " +título+" ?","Alerta",JOptionPane.YES_NO_OPTION,JOptionPane.ERROR_MESSAGE);
        
        if (option == JOptionPane.NO_OPTION) {
            option =2;
        }else if(option == JOptionPane.YES_OPTION){
            option =1;
        }
        try {
        switch(option){
           
            case 1:
                libreria.setPosición_Clibro(Posición_modificando);
                libreria.crearTesis(autor, título, Palabras_claves,areaAcademica, temas, descripción, edición, copias, disponibles);
                limpiar();
                TareaAcademica.setText(null);
                break;
            case 2: 
                limpiar();
                TareaAcademica.setText(null);
                Posición_modificando = Posición_modificando;
                break;
            default:
                break;
        }
        } catch (Exception e) {
        }     
        
    }
    
    
    public void limpiar(){
        Ttitulo.setText(null);
        Tautor.setText(null);
        Ttemas.setText(null);
        Tcopias.setText(null);
        Tedición.setText(null);
        TPalabrasClaves.setText(null);
        Adescripción.setText(null);
    }
    
    public void comprobarRellenado(){
        boolean estadoLlenado = true;
        do{
        if(Tautor.getText().equals("")){
            Tautor.setText(JOptionPane.showInputDialog(Tautor,"Ingresa un Autor,por favor"));
        }else if(Ttemas.getText().equals("")){
            Ttemas.setText(JOptionPane.showInputDialog(Ttemas,"Ingresa un tema,por favor"));
        }else if(Adescripción.getText().equals("")){
            Adescripción.setText(JOptionPane.showInputDialog(Adescripción,"Ingresa una descripción,por favor"));;
        }else if(Tcopias.getText().equals("")){
            Tcopias.setText(JOptionPane.showInputDialog(Tcopias,"Ingresa un numero de copias,por favor"));;
        }else if(Tedición.getText().equals("")){
            Tedición.setText(JOptionPane.showInputDialog(Tedición,"Ingresa un numero de edición,por favor"));
        }else if(TPalabrasClaves.getText().equals("")){
            TPalabrasClaves.setText(JOptionPane.showInputDialog(TPalabrasClaves,"Ingresa al menos una clave,por favor"));
        }else if(Ttitulo.getText().equals("")){
            Ttitulo.setText(JOptionPane.showInputDialog(Ttitulo,"Ingresa un título,por favor"));
        }else if(CopcionBibliografia.getSelectedItem().equals("")) {
            String option = JOptionPane.showInputDialog(CopcionBibliografia,"Elige un tipo de bibliografia: \n 0 \n 1 \n 2");
            switch(option){
                case "0":
                    CopcionBibliografia.setSelectedItem("(0) Libro");
                    break;
                case "1":
                    CopcionBibliografia.setSelectedItem("(1) Revista");
                    break;
                case "2": 
                    CopcionBibliografia.setSelectedItem("(2) Tesis");
                    break;
                default: 
                    break;
            }
       /* }else if(CopcionBibliografia.getSelectedItem().equals("(1) Revista")){
             if (TfrecuenciaActual.getText().equals("")) {
                        TfrecuenciaActual.setText(JOptionPane.showInputDialog(TfrecuenciaActual,"Ingresa una frecuencia actual,por favor"));;
             }
        }else if(CopcionBibliografia.getSelectedItem().equals("(2) Tesis")){
            if (TareaAcademica.getText().equals("")) {
                        TareaAcademica.setText(JOptionPane.showInputDialog(TareaAcademica,"Ingresa una área academica,por favor"));;
             }*/
        }else{
            estadoLlenado = false;
        }
        }while(estadoLlenado);
    }
    
    public void llenarCopcion(){
        CopcionBibliografia.addItem("");
        CopcionBibliografia.addItem("(0) Libro");
        CopcionBibliografia.addItem("(1) Revista");
        CopcionBibliografia.addItem("(2) Tesis");
    }
    
    public void cambiandoForm(){
        CopcionBibliografia.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
           
                if(CopcionBibliografia.getSelectedItem().equals("(0) Libro")){
                    PmodificaBibliografia.removeAll();
                    PmodificaBibliografia.repaint();
                    configurarUsuario();
            }else if (CopcionBibliografia.getSelectedItem().equals("(1) Revista")) {
                    PmodificaBibliografia.removeAll();
                    PmodificaBibliografia.repaint();
                    configurarUsuario();
                    configurarParaRevista();
                }else if (CopcionBibliografia.getSelectedItem().equals("(2) Tesis")) {
                    PmodificaBibliografia.removeAll();
                    PmodificaBibliografia.repaint();
                    configurarUsuario();
                    configurarParaTesis();
                }
                
            }
        });
        
    }
    
    public void obtenerDatosLibro(Biblioteca.Biblioteca_201708938 libreria){
         String buscaTemas="";
         String buscaPalabras="";
         Ttitulo.setText(libreria.libro[Posición_modificando].título);
         Tautor.setText(libreria.libro[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.libro[Posición_modificando].edición));
         for (int i = 0; i < libreria.libro[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.libro[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.libro[Posición_modificando].copias));
         for (int i = 0; i < libreria.libro[Posición_modificando].palabrasClaves.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.libro[Posición_modificando].palabrasClaves[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.libro[Posición_modificando].descripción);
    }
    
    public void obtenerDatosRevista(Biblioteca.Biblioteca_201708938 libreria){
         String buscaTemas="";
         String buscaPalabras="";
         Ttitulo.setText(libreria.revista[Posición_modificando].título);
         Tautor.setText(libreria.revista[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.revista[Posición_modificando].edición));
         for (int i = 0; i < libreria.revista[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.revista[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.revista[Posición_modificando].copias));
         for (int i = 0; i < libreria.revista[Posición_modificando].palabrasClave.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.revista[Posición_modificando].palabrasClave[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.revista[Posición_modificando].descripción);
        TfrecuenciaActual.setText(libreria.revista[Posición_modificando].frecuencia_actual);
    }
    
    public void obtenerDatosTesis(Biblioteca.Biblioteca_201708938 libreria){
        String buscaTemas="";
         String buscaPalabras="";
         Ttitulo.setText(libreria.tesis[Posición_modificando].título);
         Tautor.setText(libreria.tesis[Posición_modificando].autor);
         Tedición.setText(Integer.toString(libreria.tesis[Posición_modificando].edición));
         for (int i = 0; i < libreria.tesis[Posición_modificando].temas.length; i++) {
            buscaTemas = buscaTemas +","+libreria.tesis[Posición_modificando].temas[i];
        }
         Ttemas.setText(buscaTemas);
         Tcopias.setText(Integer.toString(libreria.tesis[Posición_modificando].copias));
         for (int i = 0; i < libreria.tesis[Posición_modificando].palabrasClave.length; i++) {
            buscaPalabras = buscaPalabras +","+libreria.tesis[Posición_modificando].palabrasClave[i];
        }
         TPalabrasClaves.setText(buscaPalabras);
         Adescripción.setText(libreria.tesis[Posición_modificando].descripción);
         TareaAcademica.setText(libreria.tesis[Posición_modificando].area);
    }

}
