package Usuarios.admin;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
public class OpcionCreaBibliografa_201708938 {

JPanel PopcionCreaBibliografia = new JPanel();
JFrame FopcionCreaBibliografia = new JFrame();
JLabel nOpcionCreaBibliografia = new JLabel();
JButton BcargaIndividual = new JButton();
JButton BcargaMasiva =new JButton();
JButton Bregresar = new JButton();
    
public void configurarOpcionCreaBibliografia(){
    FopcionCreaBibliografia.setSize(750,550);
    FopcionCreaBibliografia.setLocationRelativeTo(null);
    FopcionCreaBibliografia.setDefaultCloseOperation(FopcionCreaBibliografia.EXIT_ON_CLOSE);
    FopcionCreaBibliografia.setTitle("Crea Bibliografía");
    FopcionCreaBibliografia.add(PopcionCreaBibliografia);
    PopcionCreaBibliografia.setLayout(null);
    PopcionCreaBibliografia.setBounds(0,0,FopcionCreaBibliografia.getWidth(),FopcionCreaBibliografia.getHeight());
    PopcionCreaBibliografia.setBackground(Color.decode("#BCE081"));
    nOpcionCreaBibliografia.setText("Elige una opcion: ");
    nOpcionCreaBibliografia.setFont(new Font("Serif",Font.BOLD, 28));
    nOpcionCreaBibliografia.setForeground(Color.white);
    nOpcionCreaBibliografia.setBounds(280,80,250,50);
    PopcionCreaBibliografia.add(nOpcionCreaBibliografia);
    BcargaMasiva.setText("Carga Masiva");
    BcargaMasiva.setFont(new Font("Serif",Font.BOLD, 28));
    BcargaMasiva.setForeground(Color.orange);
    BcargaMasiva.setBounds(390,230,320,100);
    PopcionCreaBibliografia.add(BcargaMasiva);
    BcargaIndividual.setText("Carga Individual");
    BcargaIndividual.setFont(new Font("Serif",Font.BOLD, 28));
    BcargaIndividual.setForeground(Color.ORANGE);
    BcargaIndividual.setBounds(50,230,320,100);
    PopcionCreaBibliografia.add(BcargaIndividual);
    Bregresar.setText("<- Regresar ");
    Bregresar.setForeground(Color.green);
    Bregresar.setFont(new Font("Serif",Font.CENTER_BASELINE,20));
    Bregresar.setBounds(280,410,200,50);
    PopcionCreaBibliografia.add(Bregresar);
}

    public OpcionCreaBibliografa_201708938() {
    configurarOpcionCreaBibliografia();
    FopcionCreaBibliografia.show(true);
    }

}
