
package Usuarios.admin;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class MostrarBibliografia_201708938 {
    
JFrame FmodificarBibliografia = new JFrame();
JPanel PmodificarBibliografia = new JPanel();
JLabel nTitulo = new JLabel();
JLabel nOrdenarPor = new JLabel();
JLabel nTipo = new JLabel();        
JTextField Ttitulo = new JTextField();
JRadioButton BRtitulo = new JRadioButton();
JRadioButton BRpalabraClave = new JRadioButton();
JComboBox CordenarPor = new JComboBox();
JComboBox Ctipo = new JComboBox();
JButton Bbuscar = new JButton();
JButton Bregresar = new JButton();
int Posición_buscar=-1;

JTable TablaMostrar;
DefaultTableModel modeloTabla;
JScrollPane STablaMostrar = new JScrollPane();

//Variables para realizar el ordenamiento burbuja
String [][]recolectaDatos;
String [] copias,disponibles,tipo;

String [] columnas = {"Titulo","Autor","Tipo","Edición","Copias","Disponibles",};

    public MostrarBibliografia_201708938() {
    configurarMostrarBibliografia();
    llenarCombos();
    //CordenAccion();
    //ordenarPorOpcionCorden();
    BRtitulo.setSelected(true);
    FmodificarBibliografia.show(true);
    }
   


public void configurarMostrarBibliografia(){
    FmodificarBibliografia.setSize(900,750);
    FmodificarBibliografia.setTitle("Mostrar Bibliografía");
    FmodificarBibliografia.setLocationRelativeTo(null);
    FmodificarBibliografia.setDefaultCloseOperation(FmodificarBibliografia.EXIT_ON_CLOSE);
    FmodificarBibliografia.add(PmodificarBibliografia);
    PmodificarBibliografia.setBounds(0,0,FmodificarBibliografia.getWidth(),FmodificarBibliografia.getHeight());
    PmodificarBibliografia.setLayout(null);
    PmodificarBibliografia.setBackground(Color.decode("#BCE081"));
    
    nTitulo.setText("Titulo");
    nTitulo.setBounds(30,30,100,30);
    nTitulo.setFont(new Font("Arial",Font.BOLD,25));
    nTitulo.setForeground(Color.orange);
    PmodificarBibliografia.add(nTitulo);
    Ttitulo.setBounds(150,30,300,50);
    PmodificarBibliografia.add(Ttitulo);
    BRtitulo.setBounds(490,20,120,30);
    BRtitulo.setText("Titulo");
    PmodificarBibliografia.add(BRtitulo);
    BRpalabraClave.setText("Palabra Clave");
    BRpalabraClave.setBounds(490,60,120,30);
    PmodificarBibliografia.add(BRpalabraClave);
    Bbuscar.setText("Buscar");
    Bbuscar.setBounds(650,30,150,50);
    PmodificarBibliografia.add(Bbuscar);
    nOrdenarPor.setText("Ordenar por: ");
    nOrdenarPor.setBounds(30,130,220,50);
    nOrdenarPor.setFont(new Font("Arial",Font.BOLD,25));
    nOrdenarPor.setForeground(Color.orange);
    PmodificarBibliografia.add(nOrdenarPor);
    CordenarPor.setBounds(230,130,160,50);
    PmodificarBibliografia.add(CordenarPor);
    nTipo.setText("Tipo: ");
    nTipo.setBounds(500,130,100,50);
    nTipo.setFont(new Font("Arial",Font.BOLD,25));
    nTipo.setForeground(Color.orange);
    PmodificarBibliografia.add(nTipo);
    Ctipo.setBounds(650,130,150,50);
    PmodificarBibliografia.add(Ctipo);
    modeloTabla = new DefaultTableModel(null,columnas);
    TablaMostrar = new JTable(modeloTabla);
    STablaMostrar.setViewportView(TablaMostrar);
    STablaMostrar.setBounds(30,230,800,360);
    PmodificarBibliografia.add(STablaMostrar);
    Bregresar.setText("Regresar ");
    Bregresar.setBounds(320,620,150,50);
    PmodificarBibliografia.add(Bregresar);

}

public void buscarPorTitulo(Biblioteca.Biblioteca_201708938 libreria){
        String titulo = Ttitulo.getText();
        for (int i = 0; i < libreria.libro.length; i++) {
            try {
                if (titulo.equals(libreria.libro[i].título)) {
                Posición_buscar = i;
                libreria.libro[i].numeroDeBusqueda++;
                    llenarTablaLibro(libreria);
            }
            } catch (Exception e) {
                continue;
            }
            
        }
        for (int i = 0; i < libreria.revista.length; i++) {
            try {
             if (titulo.equals(libreria.revista[i].título)) {
                Posición_buscar = i;
                libreria.revista[i].numeroDeBusqueda++;
                 llenarTablaRevista(libreria);
            }
            } catch (Exception e) {
                continue;
            }
           
        }    
        for (int i = 0; i < libreria.tesis.length; i++) {
            try {
                if (titulo.equals(libreria.tesis[i].título)) {
                Posición_buscar = i;
                libreria.tesis[i].numeroDeBusqueda++;   
                llenarTablaTesis(libreria);
            }
            } catch (Exception e) {
                continue;
            }
        }
        if (Posición_buscar==-1) {
            JOptionPane.showMessageDialog(PmodificarBibliografia,"No se encuentra una biliografia de "+titulo+"");
        }
        
    }
public void buscarPorPalabras(Biblioteca.Biblioteca_201708938 libreria){
    String [] palabrasClaves = Ttitulo.getText().split(",");
    int sumaPosiciones = libreria.posición_Clibro+libreria.posición_Crevista+libreria.posición_Ctesis;
    boolean estadoLibro =false;
    boolean estadoRevista =false;
    boolean estadoTesis =false;
    /*  for (int i = 0; i < sumaPosiciones+1; i++) {
        System.out.println("i" +i);
        try {
        for (int j = 0; j < libreria.libro[i].palabrasClaves.length; j++) {
            System.out.println("j "+j);
        }} catch (Exception e) {
            System.out.println("Error en j");
            continue;
        } 
    }
    */
    for (int i = 1; i <= sumaPosiciones; i++) {
        try {
            for (int j = 0; j < libreria.libro[i].palabrasClaves.length; j++) {
                   try{
                       for (int k = 0; k < palabrasClaves.length; k++) {
                           try {
                               if (palabrasClaves[k].equals(libreria.libro[i].palabrasClaves[j])) {
                                Posición_buscar = i;
                                libreria.libro[i].numeroDeBusqueda++;
                               estadoLibro = true;  
                               }
                           } catch (Exception e) {
                               continue;
                           }
                       }
                   } catch (Exception e) {
                   continue;
                }
            }
            if (estadoLibro==true) {
                llenarTablaLibro(libreria);
            }
            
            for (int j = 0; j < libreria.revista[i].palabrasClave.length; j++) {
                try {
                   for (int k = 0; k < palabrasClaves.length; k++) {
                           try {
                               if (palabrasClaves[k].equals(libreria.revista[i].palabrasClave[j])) {
                                Posición_buscar = i;
                                libreria.revista[i].numeroDeBusqueda++;
                               estadoRevista = true;  
                               }
                           } catch (Exception e) {
                               continue;
                           }
                       }
                } catch (Exception e) {
                    continue;
                }
            }
            if (estadoRevista==true) {
                llenarTablaRevista(libreria);
            }
            
            for (int j = 0; j < libreria.tesis[i].palabrasClave.length; j++) {
                try {
                    for (int k = 0; k < palabrasClaves.length; k++) {
                           try {
                               if (palabrasClaves[k].equals(libreria.tesis[i].palabrasClave[j])) {
                                Posición_buscar = i;
                                libreria.tesis[i].numeroDeBusqueda++;
                               estadoTesis = true;  
                               }
                           } catch (Exception e) {
                               continue;
                           }
                       }
                } catch (Exception e) {
                    continue;
                }
            }
             if (estadoTesis==true) {
                llenarTablaTesis(libreria);
            }
            
        } catch (Exception e) {
            continue;
        }
        
        if (Posición_buscar ==-1) {
            JOptionPane.showMessageDialog(PmodificarBibliografia,"No existe esa bibliografia: "+ palabrasClaves);
        }
    }
}


    public void llenarTablaLibro(Biblioteca.Biblioteca_201708938 libreria){
         String autor = libreria.libro[Posición_buscar].autor;
         String titulo = libreria.libro[Posición_buscar].título;
         int edición =libreria.libro[Posición_buscar].edición;
         int copias = libreria.libro[Posición_buscar].copias;
         int disponibles= libreria.libro[Posición_buscar].disponibles;
         Object[]datos = {titulo,autor,"Libro",edición,copias,disponibles};
         modeloTabla.addRow(datos);
    }
    
    public void llenarTablaRevista(Biblioteca.Biblioteca_201708938 libreria){
         String autor = libreria.revista[Posición_buscar].autor;
         String titulo = libreria.revista[Posición_buscar].título;
         int edición =libreria.revista[Posición_buscar].edición;
         int copias = libreria.revista[Posición_buscar].copias;
         int disponibles= libreria.revista[Posición_buscar].displinibles;
         Object[]datos = {titulo,autor,"Revista",edición,copias,disponibles};
         modeloTabla.addRow(datos);
    }
    public void llenarTablaTesis(Biblioteca.Biblioteca_201708938 libreria){
         String autor = libreria.tesis[Posición_buscar].autor;
         String titulo = libreria.tesis[Posición_buscar].título;
         int edición =libreria.tesis[Posición_buscar].edición;
         int copias = libreria.tesis[Posición_buscar].copias;
         int disponibles= libreria.tesis[Posición_buscar].disponibles;
         Object[]datos = {titulo,autor,"Tesis",edición,copias,disponibles};
         modeloTabla.addRow(datos);
    }
    
    public void buscarSegúnOpcion(Biblioteca.Biblioteca_201708938 libreria){
        if (BRtitulo.isSelected()) {
            buscarPorTitulo(libreria);
        }else if (BRpalabraClave.isSelected()) {
            buscarPorPalabras(libreria);
        }else{
            JOptionPane.showMessageDialog(PmodificarBibliografia,"Selecciona solo una opcion =D");
        }
        
    }
    
    public void llenarCombos(){
        CordenarPor.addItem("Copias");
        CordenarPor.addItem("Disponibles");
        CordenarPor.addItem("Tipo");
        Ctipo.addItem("Ascendentemente");
        Ctipo.addItem("Descendentemete");
    }

    public void extraerFilas(){
        recolectaDatos = new String[modeloTabla.getRowCount()][6];
        copias = new String[modeloTabla.getRowCount()];
        disponibles = new String[modeloTabla.getRowCount()];
        tipo = new String[modeloTabla.getRowCount()];
        
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            String titulo = TablaMostrar.getValueAt(i,0).toString();
            String autor = TablaMostrar.getValueAt(i,1).toString();
            String tipo = TablaMostrar.getValueAt(i, 2).toString();
            String edición = TablaMostrar.getValueAt(i,3).toString();
            String copias = TablaMostrar.getValueAt(i,4).toString();
            String disponibles = TablaMostrar.getValueAt(i,5).toString();
            recolectaDatos[i][0] = titulo;
            recolectaDatos[i][1] = autor;
            recolectaDatos[i][2] = tipo;
            this.tipo[i] = tipo;
            recolectaDatos[i][3] = edición;
            recolectaDatos[i][4] = copias;
            this.copias[i] =copias;
            recolectaDatos[i][5] = disponibles;
            this.disponibles[i] = disponibles;
            System.out.println("RowCount> " +modeloTabla.getRowCount());
        }
    }

    public void ordenarPorOpcionCorden(){
                if (!Ctipo.getSelectedItem().equals("Ascendentemente")) {
                    limpiarTabla();
                    TablaMostrar.repaint();
                    ordenarAscendentemente();
                    //verificarDato();
                }else{
                    limpiarTabla();
                    ordenarDescendentemente();
                    //verificarDato();
                }
                
    }
    
    public void ordenarAscendentemente(){
        //limpiarTabla();
        if (CordenarPor.getSelectedItem().equals("Copias")) {
            for (int i = 1; i < copias.length; i++) {
                for (int j = 0; j < copias.length-1; j++) {
                    try {
                    if (copias[j].toString().compareTo(copias[j+1].toString())>0) {
                        String temp = copias[j].toString();
                        copias[j] = copias[j+1];
                        copias[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
            llenarTablaPorCopias();
        }
        ///
        if (CordenarPor.getSelectedItem().equals("Disponibles")) {
            for (int i = 1; i < disponibles.length; i++) {
                for (int j = 0; j < disponibles.length-1; j++) {
                    try {
                    if (disponibles[j].toString().compareTo(disponibles[j+1].toString())>0) {
                        String temp = disponibles[j].toString();
                        disponibles[j] = disponibles[j+1];
                        disponibles[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
            llenarTablaPorDisponibles();
        }
        //
        if (CordenarPor.getSelectedItem().equals("Tipo")) {
            for (int i = 1; i < tipo.length; i++) {
                for (int j = 0; j < tipo.length-1; j++) {
                    try {
                    if (tipo[j].toString().compareTo(tipo[j+1].toString())>0) {
                        String temp = tipo[j].toString();
                        tipo[j] = tipo[j+1];
                        tipo[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
        }
        llenarTablaPorTipo();
    }
    
    public void ordenarDescendentemente(){
      //  limpiarTabla();
        if (CordenarPor.getSelectedItem().equals("Copias")) {
            for (int i = 1; i < copias.length; i++) {
                for (int j = 0; j < copias.length-1; j++) {
                    try {
                    if (copias[j].toString().compareTo(copias[j+1].toString())<0) {
                        String temp = copias[j].toString();
                        copias[j] = copias[j+1];
                        copias[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
        llenarTablaPorCopias();
        }
        
        
        
        ///
        if (CordenarPor.getSelectedItem().equals("Disponibles")) {
            for (int i = 1; i < disponibles.length; i++) {
                for (int j = 0; j < disponibles.length-1; j++) {
                    try {
                    if (disponibles[j].toString().compareTo(disponibles[j+1].toString())<0) {
                        String temp = disponibles[j].toString();
                        disponibles[j] = disponibles[j+1];
                        disponibles[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
            llenarTablaPorDisponibles();
        }
        //
        if (CordenarPor.getSelectedItem().equals("Tipo")) {
            for (int i = 1; i < tipo.length; i++) {
                for (int j = 0; j < tipo.length-1; j++) {
                    try {
                    if (tipo[j].toString().compareTo(tipo[j+1].toString())<0) {
                        String temp = tipo[j].toString();
                        tipo[j] = tipo[j+1];
                        tipo[j+1] = temp;
                    }    
                    } catch (Exception e) {
                    continue;
                    }
                    
                }
            }
        }
        llenarTablaPorTipo();
    }
    
    public void llenarTablaPorCopias(){
        //limpiarTabla();
        for (int i = 0; i <=copias.length; i++) {
            try{
                for (int j = 0; j <=copias.length; j++) {
                     if (recolectaDatos[j][4].equals(copias[i])) {
            String a= recolectaDatos[j][0];
            String b= recolectaDatos[j][1];
            String c = recolectaDatos[j][2];
            String d =recolectaDatos[j][3];
            String e = recolectaDatos[j][4];
            String f = recolectaDatos[j][5];
            
            String []algo ={a,b,c,d,e,f};
            
           modeloTabla.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length "+ copias.length);
            System.out.println("eliminando "+i);
        }
        }   
    }
    
    public void llenarTablaPorDisponibles(){
       // limpiarTabla();
        for (int i = 0; i <=disponibles.length; i++) {
            try{
                for (int j = 0; j <=disponibles.length; j++) {
                     if (recolectaDatos[j][5].equals(disponibles[i])) {
            String a= recolectaDatos[j][0];
            String b= recolectaDatos[j][1];
            String c = recolectaDatos[j][2];
            String d =recolectaDatos[j][3];
            String e = recolectaDatos[j][4];
            String f = recolectaDatos[j][5];
            
            String []algo ={a,b,c,d,e,f};
            
           modeloTabla.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length "+ disponibles.length);
            System.out.println("eliminando "+i);
        }
        }
       // limpiarDatosRepetidosTabla(disponibles);
    }
    
    public void llenarTablaPorTipo(){
     //   limpiarTabla();
        for (int i = 0; i <=tipo.length; i++) {
            try{
                for (int j = 0; j <=tipo.length; j++) {
                     if (recolectaDatos[j][2].equals(tipo[i])) {
            String a= recolectaDatos[j][0];
            String b= recolectaDatos[j][1];
            String c = recolectaDatos[j][2];
            String d =recolectaDatos[j][3];
            String e = recolectaDatos[j][4];
            String f = recolectaDatos[j][5];
            
            String []algo ={a,b,c,d,e,f};
           System.out.println("Tipolength "+ tipo.length);
           modeloTabla.addRow(algo);
            }else{
                System.out.println("no found a");
            }
          }
           
            
        }catch(Exception e){
            System.out.println("copias length "+ tipo.length);
            System.out.println("eliminando "+i);
        }
        }
        //limpiarDatosRepetidosTabla(tipo);
    }
    
 /*    public void limpiarDatosRepetidosTabla(String tamañoReal[]){
        
        for (int i = tamañoReal.length; i < modeloTabla.getRowCount(); i++) {
           // try {
                modeloTabla.removeRow(i);
            //i-=1;
            //} catch (Exception e) {
            //    System.out.println(""+e);
           // }
            
        }
        //modeloTabla.setRowCount(tamañoReal.length);
    }
    /* public void limpiarRepetidosTabla(){
         int datos_buenos = ;
         for (int i = 0; i <modeloTabla.getRowCount(); i++) {
             
         }
     }*/
    public void limpiarTabla(){
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            modeloTabla.removeRow(i);
            i=-1;
        }
       // modeloTabla.setRowCount(0);
        TablaMostrar.repaint();
    }
    public void verificarDato(){
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            String a =modeloTabla.getValueAt(i,0).toString().trim();
            for (int j = i+1; j < modeloTabla.getRowCount(); j++) {
                if (a.equals(modeloTabla.getValueAt(j, 0).toString().trim())) {
                
                    try {
                     modeloTabla.removeRow(j); 
                        System.out.println("Se elimino "+j);
                    } catch (Exception e) {
                    
                    }
            }
            }
            
        }
        
    }
}
