package Usuarios.admin;

import Biblioteca.Biblioteca_201708938;
import Usuarios.usuarioSearch_201708938;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class InicioAdmin_201708938 {
    
    JFrame FinicioAdmin = new JFrame();
    JPanel PinicioAdmin = new JPanel();
    JLabel nUsuarios = new JLabel();
    JLabel nBibliografias = new JLabel();
    JButton Bcrear_usuario = new JButton();
    JButton Bmodificar_usuario = new JButton();
    JButton Beliminar_usuario = new JButton();
    JButton Bmostrar_usuario = new JButton();
    JButton Bcrear_bibliografia = new JButton();
    JButton Bmodificar_bibliografia = new JButton();
    JButton Beliminar_bibliografia = new JButton();
    JButton Bmostrar_bibliografia=new JButton();
    JButton Breporte = new JButton();
    JButton Bsalir = new JButton();
    int correlativo;
    int correlativo_creaBibliografiaL;
    int correlativo_creaBibliografiaR;
    int correlativo_creaBibliografiaT;
    
    //
    JLabel imgUser = new JLabel();
    JLabel imgBibliografia = new JLabel();
    ImageIcon IconUser = new ImageIcon(getClass().getResource("/imagenes/usuarios_201708938.png"));
    ImageIcon IconBibliografia = new ImageIcon(getClass().getResource("/imagenes/libro_201708938.png"));
    //
    public  Usuarios.usuarioSearch_201708938 creandoUsuario = new usuarioSearch_201708938();
    public Biblioteca_201708938 creandoBibliografía = new Biblioteca_201708938();
    
    public InicioAdmin_201708938() {
        configurarInicioAdmin();
        FinicioAdmin.show(true);
        presionarBCreaUsuario();
        presionarBModificarUsuario();
        presionarBEliminarUsuario();
        presionarBMostrarUsuario();
        //presionarBCrearBibliografia(); reemplazado por: mostrarOpcionesCrearBibliografia();
        mostrarOpcionesCrearBibliografia();
        presionarBmodificarBibliografía();
        presionarBeliminarBibliografia();
        presionarBmostrarBibliografia();
        pulsarBgeneraReporte();
        //salir();
    }
    
    
    public void configurarInicioAdmin(){
    FinicioAdmin.setSize(750,525);
    FinicioAdmin.setLocationRelativeTo(null);
    FinicioAdmin.setTitle("Administrador");
    FinicioAdmin.setDefaultCloseOperation(FinicioAdmin.EXIT_ON_CLOSE);
    FinicioAdmin.add(PinicioAdmin);
    PinicioAdmin.setLayout(null);
    PinicioAdmin.setBounds(0,0,FinicioAdmin.getWidth(),FinicioAdmin.getHeight());
    PinicioAdmin.setBackground(Color.decode("#BCE081"));
    nUsuarios.setBounds(300,40,120,25);
    nUsuarios.setText("Usuarios");
    nUsuarios.setFont(new Font("Serif",Font.BOLD,30));
    nUsuarios.setForeground(Color.white);
    PinicioAdmin.add(nUsuarios);
    
    imgUser.setIcon(IconUser);
    imgUser.setBounds(440,20,120,100);
    PinicioAdmin.add(imgUser);
    imgBibliografia.setIcon(IconBibliografia);
    imgBibliografia.setBounds(450,220,120,100);
    PinicioAdmin.add(imgBibliografia);
    
    Bcrear_usuario.setBounds(100, 125,100,35);
    Bcrear_usuario.setText("Crear");
    Bcrear_usuario.setFont(new Font("Serif",Font.BOLD,12));
    Bcrear_usuario.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bcrear_usuario);
    Bmodificar_usuario.setBounds(215,125,100,35);
    Bmodificar_usuario.setText("Modificar");
    Bmodificar_usuario.setFont(new Font("Serif",Font.BOLD,12));
    Bmodificar_usuario.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bmodificar_usuario);
    Beliminar_usuario.setBounds(345,125,100,35);
    Beliminar_usuario.setText("Eliminar");
    Beliminar_usuario.setFont(new Font("Serif",Font.BOLD,12));
    Beliminar_usuario.setForeground(Color.ORANGE);
    PinicioAdmin.add(Beliminar_usuario);
    Bmostrar_usuario.setBounds(475,125,100,35);
    Bmostrar_usuario.setText("Mostrar");
    Bmostrar_usuario.setFont(new Font("Serif",Font.BOLD,12));
    Bmostrar_usuario.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bmostrar_usuario);
    //
    nBibliografias.setBounds(250,240,200,35);
    nBibliografias.setText("Bibliografías");
    nBibliografias.setFont(new Font("Serif",Font.BOLD,30));
    nBibliografias.setForeground(Color.white);
    PinicioAdmin.add(nBibliografias);
    Bcrear_bibliografia.setBounds(100, 315,100,35);
    Bcrear_bibliografia.setText("Crear");
    Bcrear_bibliografia.setFont(new Font("Serif",Font.BOLD,12));
    Bcrear_bibliografia.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bcrear_bibliografia);
    Bmodificar_bibliografia.setBounds(215,315,100,35);
    Bmodificar_bibliografia.setText("Modificar");
    Bmodificar_bibliografia.setFont(new Font("Serif",Font.BOLD,12));
    Bmodificar_bibliografia.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bmodificar_bibliografia);
    Beliminar_bibliografia.setBounds(345,315,100,35);
    Beliminar_bibliografia.setText("Eliminar");
    Beliminar_bibliografia.setFont(new Font("Serif",Font.BOLD,12));
    Beliminar_bibliografia.setForeground(Color.ORANGE);
    PinicioAdmin.add(Beliminar_bibliografia);
    Bmostrar_bibliografia.setBounds(475,315,100,35);
    Bmostrar_bibliografia.setText("Mostrar");
    Bmostrar_bibliografia.setFont(new Font("Serif",Font.BOLD,12));
    Bmostrar_bibliografia.setForeground(Color.ORANGE);
    PinicioAdmin.add(Bmostrar_bibliografia);
    
    Breporte.setText("Reportes");
    Breporte.setBounds(160,400,100,30);
    PinicioAdmin.add(Breporte);
    Bsalir.setText("Salir");
    Bsalir.setBounds(500,400,60,30);
    PinicioAdmin.add(Bsalir);
    
    }
 
    public void presionarBCreaUsuario(){
        Bcrear_usuario.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                CreaUsuario_201708938 crear_usuario = new CreaUsuario_201708938();
                FinicioAdmin.setVisible(false);
                //correlativo++;
                System.out.println("s" +correlativo);
                crear_usuario.BcreaUsuario.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ae) {
                        correlativo++;
                        crear_usuario.Posición_creando = correlativo;
                        crear_usuario.Creando(creandoUsuario);
                        //correlativo++;
                    }
                });
                crear_usuario.Bcancelar.addActionListener(new ActionListener() {
   
                    public void actionPerformed(ActionEvent ae) {
                        FinicioAdmin.setVisible(true);
                        crear_usuario.FcreaUsuario.setVisible(false);
                        correlativo = crear_usuario.Posición_creando;
                       creandoUsuario.usuariosCreados();
                    }
                });
            }
        });
    }
    //creandoUsuario = busqueda -> son del mismo tipo
    public void presionarBModificarUsuario(){
        Bmodificar_usuario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                ModificarUsuario_201708938 modificar_usuario = new ModificarUsuario_201708938();
                modificar_usuario.llenarCid(creandoUsuario);
                FinicioAdmin.show(false);
               modificar_usuario.Cid.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        modificar_usuario.llenarCid(creandoUsuario);
                        String buscar_id = (String)modificar_usuario.Cid.getSelectedItem();
                        modificar_usuario.buscarDatos(creandoUsuario, buscar_id);
                        
                    }
                });
                
                modificar_usuario.BModificaUsuario.addActionListener(new ActionListener() {
                  
                    public void actionPerformed(ActionEvent ae) {
                        System.out.println("pos "+modificar_usuario.Posicion_modificar);
                        modificar_usuario.Creando(creandoUsuario,modificar_usuario.Posicion_modificar);
                        
                    }
                });
                modificar_usuario.Bcancelar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        FinicioAdmin.setVisible(true);
                        modificar_usuario.FModificaUsuario.setVisible(false);
                        creandoUsuario.usuariosCreados();
                    }
                });
            }
        });
    }
    
    public void presionarBEliminarUsuario(){
           Beliminar_usuario.addActionListener(new ActionListener() {
               
               public void actionPerformed(ActionEvent ae) {
                   EliminaUsuario_201708938 eliminar_usuario = new EliminaUsuario_201708938();
                   eliminar_usuario.llenarCid(creandoUsuario);
                   FinicioAdmin.show(false);
                   eliminar_usuario.Cid.addActionListener(new ActionListener() {
                       
                       public void actionPerformed(ActionEvent ae) {
                           eliminar_usuario.llenarCid(creandoUsuario);
                           String buscar_id = (String)eliminar_usuario.Cid.getSelectedItem();
                           eliminar_usuario.buscarDatos(creandoUsuario, buscar_id);
                       }
                   });
                   
                  
                   eliminar_usuario.BEliminarUsuario.addActionListener(new ActionListener() {
                       
                       public void actionPerformed(ActionEvent ae) {
                           eliminar_usuario.eliminando(creandoUsuario);
                       }
                   });
                   eliminar_usuario.Bcancelar.addActionListener(new ActionListener() {
                       
                       public void actionPerformed(ActionEvent ae) {
                           FinicioAdmin.show(true);
                           eliminar_usuario.FEliminaUsuario.show(false);
                       }
                   });
               }
           });
    }
    
    public void presionarBMostrarUsuario(){
        Bmostrar_usuario.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                MostrarUsuario_201708938 mostrar_usuario = new MostrarUsuario_201708938(creandoUsuario);
                FinicioAdmin.show(false);
                mostrar_usuario.Bregresar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        FinicioAdmin.show(true);
                        
                        mostrar_usuario.FMostrarUsuario.show(false);
                    }
                });
            }
        });
        
        
    }
    
    public void presionarBCrearBibliografia(OpcionCreaBibliografa_201708938 opcion){
               CreaBibliografia_201708938 crear_bibliografia = new CreaBibliografia_201708938();
               crear_bibliografia.BcreaBibliografia.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                       crear_bibliografia.comprobarRellenado();
                       if (crear_bibliografia.CopcionBibliografia.getSelectedItem().equals("(0) Libro")) {
                           correlativo_creaBibliografiaL++;
                           crear_bibliografia.Posición_creandoLibro = correlativo_creaBibliografiaL;
                           try {
                               crear_bibliografia.creandoLibro(creandoBibliografía);
                           } catch (Exception e) {
                               correlativo_creaBibliografiaL--;
                               JOptionPane.showMessageDialog(crear_bibliografia.PcreaBibliografia,"Datos incorrectos" );
                           }
                           System.out.println("Pos L "+crear_bibliografia.Posición_creandoLibro);
                       }else if(crear_bibliografia.CopcionBibliografia.getSelectedItem().equals("(1) Revista")){
                           correlativo_creaBibliografiaR++;
                           crear_bibliografia.Posición_creandoRevista = correlativo_creaBibliografiaR;
                           try {
                               crear_bibliografia.creandoRevista(creandoBibliografía);
                           } catch (Exception e) {
                                correlativo_creaBibliografiaR--;
                               JOptionPane.showMessageDialog(crear_bibliografia.PcreaBibliografia,"Datos incorrectos" );
                           }
                           System.out.println("Pos R "+crear_bibliografia.Posición_creandoRevista);
                       }else if(crear_bibliografia.CopcionBibliografia.getSelectedItem().equals("(2) Tesis")){
                           correlativo_creaBibliografiaT++;
                           crear_bibliografia.Posición_creandoTesis = correlativo_creaBibliografiaT;
                           try {
                                crear_bibliografia.creandoTesis(creandoBibliografía);    
                           } catch (Exception e) {
                                correlativo_creaBibliografiaL--;
                               JOptionPane.showMessageDialog(crear_bibliografia.PcreaBibliografia,"Datos incorrectos" );
                           }
                           System.out.println("Pos T "+crear_bibliografia.Posición_creandoTesis);
                       }
                       
                   }
               });
                    
                        crear_bibliografia.Bcancelar.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                        crear_bibliografia.FcreaBibliografia.show(false);
                        opcion.FopcionCreaBibliografia.show(true);
                   }
               });
        
    }


    public void mostrarOpcionesCrearBibliografia(){
        Bcrear_bibliografia.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
            OpcionCreaBibliografa_201708938 opcion_crear_bibliografia = new OpcionCreaBibliografa_201708938();
            FinicioAdmin.show(false);
            opcion_crear_bibliografia.BcargaIndividual.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                opcion_crear_bibliografia.FopcionCreaBibliografia.show(false);
                presionarBCrearBibliografia(opcion_crear_bibliografia);
            }
        });
            
            opcion_crear_bibliografia.BcargaMasiva.addActionListener(new ActionListener() {
                
                public void actionPerformed(ActionEvent ae) {
                    opcion_crear_bibliografia.FopcionCreaBibliografia.show(false);
                    presionarBcargaMasiva(opcion_crear_bibliografia);
                   
                }
            });
            
            opcion_crear_bibliografia.Bregresar.addActionListener(new ActionListener() {
                
                public void actionPerformed(ActionEvent ae) {
                    opcion_crear_bibliografia.FopcionCreaBibliografia.show(false);
                    FinicioAdmin.show(true);
                }
            });
            
            }
        });
       
        
    }
    
    public void presionarBcargaMasiva(OpcionCreaBibliografa_201708938 opcion){
        CreaBibliografiaMasiva_201708938 crear_bibliografia_masiva = new CreaBibliografiaMasiva_201708938();
        crear_bibliografia_masiva.Bcargar.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                String [] cargaParaDatos;
                String [] lineaCarga = crear_bibliografia_masiva.AcargaMasiva.getText().split("\n");
                System.out.println("lineaCarga "+lineaCarga[0]);
                System.out.println("Length " +lineaCarga.length);
                for (int i = 0; i <=lineaCarga.length-1; i++) {
                    cargaParaDatos = lineaCarga[i].split(";");
                    crear_bibliografia_masiva.datos =cargaParaDatos;
                  /*  for (int j = 0; j < cargaParaDatos.length-1; j++) {
                        //Comprobar los datos entrantes
                    System.out.println("Datos recibidos" +crear_bibliografia_masiva.datos[j]);
                    }*/
                        if(crear_bibliografia_masiva.datos[0].equals("0")){
                            correlativo_creaBibliografiaL++;
                            crear_bibliografia_masiva.Posición_creandoLibro = correlativo_creaBibliografiaL;
                            try {
                                crear_bibliografia_masiva.creandoLibro(creandoBibliografía);
                            } catch (Exception e) {
                            correlativo_creaBibliografiaL--;
                            JOptionPane.showMessageDialog(crear_bibliografia_masiva.PcreaBibliografiaMasiva,"Datos incorrectos para libro" );
                            }
                            
                        }else if(crear_bibliografia_masiva.datos[0].equals("1")){
                            correlativo_creaBibliografiaR++;
                            crear_bibliografia_masiva.Posición_creandoRevista = correlativo_creaBibliografiaR;
                            try {
                                crear_bibliografia_masiva.creandoRevista(creandoBibliografía);
                            } catch (Exception e) {
                            correlativo_creaBibliografiaR--;
                            JOptionPane.showMessageDialog(crear_bibliografia_masiva.PcreaBibliografiaMasiva,"Datos incorrectos para Revista" );
                            }
                         
                        }else if(crear_bibliografia_masiva.datos[0].equals("2")){
                            correlativo_creaBibliografiaT++;
                            crear_bibliografia_masiva.Posición_creandoTesis = correlativo_creaBibliografiaT;
                            try {
                                crear_bibliografia_masiva.creandoTesis(creandoBibliografía);
                            } catch (Exception e) {
                            correlativo_creaBibliografiaT--;
                            JOptionPane.showMessageDialog(crear_bibliografia_masiva.PcreaBibliografiaMasiva,"Datos incorrectos para Tesis" );
                            }
                            
                        }
                    }
                crear_bibliografia_masiva.vaciar();
                 
            }   
        });
        crear_bibliografia_masiva.Bregresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                crear_bibliografia_masiva.FcreaBibliografiaMasiva.show(false);
                opcion.FopcionCreaBibliografia.show(true);
            }
        });  
    }
    
    public void presionarBmodificarBibliografía(){
       Bmodificar_bibliografia.addActionListener(new ActionListener() {
           
           public void actionPerformed(ActionEvent ae) {
               ModificaBibliografia_201708938 modificar_bibliografía = new ModificaBibliografia_201708938();
               FinicioAdmin.show(false);
               modificar_bibliografía.Bbuscar.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                      modificar_bibliografía.buscando(creandoBibliografía);
                      
                   }
               });
               modificar_bibliografía.BmodificarBibliografia.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                       if (modificar_bibliografía.Posición_modificando!=-1) {
                           try {
                               modificar_bibliografía.modificarSegúnOpcion(creandoBibliografía);
                           } catch (Exception e) {
                           JOptionPane.showMessageDialog(PinicioAdmin,"Datos incorrectos ");
                           }
                       }else{
                           JOptionPane.showMessageDialog(PinicioAdmin,"No existe esa bibliografía ");
                       }
                   }
               });
               
               modificar_bibliografía.Bcancelar.addActionListener(new ActionListener() {
                   
                   public void actionPerformed(ActionEvent ae) {
                       modificar_bibliografía.FmodificaBibliografia.show(false);
                       FinicioAdmin.show(true);
                   }
               });
           }
       }); 
    }
    
    public void presionarBeliminarBibliografia(){ 
        Beliminar_bibliografia.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                EliminaBibliografia_201708938 eliminar_bibliografia = new EliminaBibliografia_201708938();
                FinicioAdmin.show(false);
                eliminar_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        eliminar_bibliografia.buscando(creandoBibliografía);
                    }
                });
                
                eliminar_bibliografia.BmodificarBibliografia.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                         if (eliminar_bibliografia.Posición_modificando!=-1) {
                           try {
                               eliminar_bibliografia.modificarSegúnOpcion(creandoBibliografía);
                           } catch (Exception e) {
                           }
                       }else{
                           JOptionPane.showMessageDialog(PinicioAdmin,"No existe esa bibliografía ");
                       }
                    }
                });
                eliminar_bibliografia.Bcancelar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        eliminar_bibliografia.FeliminaBibliografia.show(false);
                        FinicioAdmin.show(true);
                    }
                });
                
            }
        });
    }
    
    
    public void presionarBmostrarBibliografia(){
        Bmostrar_bibliografia.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                MostrarBibliografia_201708938 mostrar_bibliografia = new MostrarBibliografia_201708938();
                FinicioAdmin.show(false);
                mostrar_bibliografia.Bbuscar.addActionListener(new ActionListener() {
                   
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.configurarMostrarBibliografia();
                        //mostrar_bibliografia.seleccionOpcion();
                        mostrar_bibliografia.buscarSegúnOpcion(creandoBibliografía);
                        mostrar_bibliografia.extraerFilas();
                    }
                });
                mostrar_bibliografia.Ctipo.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.limpiarTabla();
                        mostrar_bibliografia.ordenarPorOpcionCorden();
                        System.out.println("Largo Modelo "+mostrar_bibliografia.modeloTabla.getRowCount());
                        System.out.println("Copias Lenght" + mostrar_bibliografia.copias.length);
                    }
                });
            
                mostrar_bibliografia.Bregresar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        mostrar_bibliografia.FmodificarBibliografia.show(false);
                        FinicioAdmin.show(true);
                    }
                });
            }
        });
    }
    
    public void pulsarBgeneraReporte(){
        Breporte.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent ae) {
                GeneraReporte_201708938 genera_reporte = new GeneraReporte_201708938();
                FinicioAdmin.show(false);
               
                genera_reporte.Bgenerar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        genera_reporte.SegunOpcionCreporte(creandoUsuario,creandoBibliografía);
                    }
                });
               
                genera_reporte.Bregresar.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent ae) {
                        genera_reporte.FgeneraReporte.show(false);
                        FinicioAdmin.show(true);
                    }
                });
                
            }
        });
    }
    
}
